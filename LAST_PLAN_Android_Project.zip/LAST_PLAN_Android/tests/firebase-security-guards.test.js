'use strict';
// Static regressions only; this does NOT replace Firebase Rules Emulator tests.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const base = path.resolve(__dirname, '..');
const rules = fs.readFileSync(path.join(base, 'firebase/firestore.rules'), 'utf8');
const bridge = fs.readFileSync(path.join(base, 'app/src/main/java/com/lastplan/app/LastPlanBridge.java'), 'utf8');
assert.match(rules, /match \/\{document=\*\*\} \{\s*allow read, write: if false;/);
assert.match(rules, /match \/guilds\/\{gid\} \{\s*allow get: if member\(gid\);\s*allow list: if false;/);
assert.match(rules, /match \/bugReports\/\{reportId\} \{[\s\S]*?allow list, update, delete: if false;/);
assert.match(rules, /function validRestriction\(gid, uid\)[\s\S]*?get\(memberPath\(gid, uid\)\)\.data\.role == 'member'/);
assert.match(rules, /getAfter\(directoryPath\(request\.resource\.data\.joinCodeHash\)\)\.data\.guildId == gid/);
assert.match(rules, /getAfter\(memberPath\(gid, request\.auth\.uid\)\)\.data\.role == 'leader'/);
assert.match(bridge, /collection\("billboard"\)\.document\("current"\)\s*\.addSnapshotListener/);
assert.match(bridge, /if \(!"leader"\.equals\(role\) && !"admin"\.equals\(role\)\) return;/);
assert.doesNotMatch(bridge, /new String\[\]\{"notices", "events", "billboard", "suggestions"\}/);
console.log('PASS: static guards for owner creation, member scope, bug inbox, billboard doc, staff suggestion listener');
console.log('NOTE: Firestore emulator allow/deny and Android device tests remain REQUIRED before publication.');
