'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const base=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(base,p),'utf8');
const provider=read('app/src/main/java/com/lastplan/app/LastPlanWidgetProvider.java');
const restore=read('app/src/main/java/com/lastplan/app/LocalReminderRestoreReceiver.java');
const html=read('app/src/main/assets/index.html');
const data=JSON.parse(read('app/src/main/assets/widget-common.json'));
assert.match(provider,/survivalRowLayout\(theme, row\.highlighted\)/);
assert.match(provider,/row\.time\.isEmpty\(\) \? R\.layout\.widget_row_empty/);
assert.doesNotMatch(provider,/child\.setInt\(R\.id\.widget_row_(accent|content)/);
assert.doesNotMatch(provider,/child\.setInt\(R\.id\.widget_row_title, "setGravity"/);
for(const theme of ['gold','navy','silver','ivory']) {
 const xml=read(`app/src/main/res/layout/widget_row_survival_${theme}_highlight.xml`);
 assert.match(xml,new RegExp(`@drawable/widget_highlight_${theme}`));
 assert.match(xml,new RegExp(`@drawable/widget_marker_${theme}`));
 assert.match(xml,/android:visibility="visible"/);
 assert.doesNotMatch(xml,/<View\s/);
 assert.match(xml,/<TextView android:id="@\+id\/widget_row_accent"/);
}
assert.match(read('app/src/main/res/layout/widget_row_empty.xml'),/android:gravity="center"/);
assert.doesNotMatch(read('app/src/main/res/layout/widget_row_survival.xml'),/<View\s/);
assert.match(restore,/LastPlanWidgetProvider\.refreshAll\(context\)/);
assert.match(html,/transform:translateY\(7px\)!important/);
assert.equal(data['0'].survival.length,6);
assert.match(read('app/build.gradle'),/versionName '1\.50'/);
console.log('PASS v1.50: native child RemoteViews static, empty state, restore, login input, Sunday data');
