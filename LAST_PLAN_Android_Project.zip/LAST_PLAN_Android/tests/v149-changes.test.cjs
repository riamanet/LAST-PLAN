'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const html=read('app/src/main/assets/index.html');
const common=JSON.parse(read('app/src/main/assets/widget-common.json'));
const widget=read('app/src/main/java/com/lastplan/app/LastPlanWidgetProvider.java');
const gradle=read('app/build.gradle');
const expected=[
  ['11:00~15:00','영지 건설',0],
  ['15:00~19:00','병사 훈련',0],
  ['19:00~23:00','기술 연구',0],
  ['23:00~03:00','까마귀 강화',0],
  ['03:00~07:00','영웅 강화',0],
  ['07:00~11:00','영지 건설',0],
];
assert.deepEqual(common['0'].survival,expected,'native widget Sunday slots must match expected');
const sunday=html.match(/0:\{\s*name:'일요일',[\s\S]*?survival:\s*\[([\s\S]*?)\],\s*note:/);
assert(sunday,'app must have Sunday survival data');
assert.deepEqual([...sunday[1].matchAll(/\['([^']+)','([^']+)',(\d+)\]/g)].map(x=>[x[1],x[2],Number(x[3])]),expected,
 'app and widget must display identical Sunday time slots');
assert.doesNotMatch(html,/일요일은 서바이벌배틀 시간표가 없습니다/);
assert.doesNotMatch(widget,/일요일은 서바이벌배틀 일정이 없습니다/);
assert.equal(common['0'].tasks.length,0,'Sunday guild-war tasks still empty');
assert.match(html,/#widgetPreviewStage\.widget-preview-stage\s*\{[\s\S]*?padding:17px 17px 15px!important/);
assert.match(html,/#loginScreen \.approved-field\.has-value \.approved-input\s*\{[\s\S]*?transform:translateY\(7px\)!important/);
assert.match(gradle,/versionCode 16/);
assert.match(gradle,/versionName '1\.50'/);
console.log('PASS v1.49: Sunday slots, native parity, login input positioning, preview-only padding, version');
