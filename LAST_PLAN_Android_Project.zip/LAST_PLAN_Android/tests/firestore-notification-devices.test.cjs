'use strict';
// Run with @firebase/rules-unit-testing in a local Firestore emulator.
const fs = require('node:fs');
const {initializeTestEnvironment, assertFails, assertSucceeds} = require('@firebase/rules-unit-testing');
const {doc, getDoc, setDoc, deleteDoc} = require('firebase/firestore');
(async () => {
  const env = await initializeTestEnvironment({
    projectId: 'demo-last-plan-devices',
    firestore: {rules: fs.readFileSync('firebase/firestore.rules', 'utf8')}
  });
  try {
    await env.withSecurityRulesDisabled(async context => {
      const db = context.firestore();
      await setDoc(doc(db, 'guilds/alpha'), {ownerUid: 'user-a', joinCodeHash:'a'.repeat(64), name:'Guild', createdAt:'now'});
      await setDoc(doc(db, 'guilds/alpha/members/user-a'), {uid:'user-a',role:'member',nickname:'A',joinCodeHash:'a'.repeat(64),joinedAt:'now'});
    });
    const owner = env.authenticatedContext('user-a').firestore();
    const other = env.authenticatedContext('user-b').firestore();
    const docPath = 'notificationDevices/user-a';
    const {serverTimestamp} = require('firebase/firestore');
    const valid = {uid:'user-a',guildId:'alpha',token:'test-fcm-token',notice:true,schedule:false,shield:false,scheduleMinutes:10,shieldMinutes:10,shieldEndsAt:'',updatedAt:serverTimestamp()};
    await assertSucceeds(setDoc(doc(owner, docPath), valid));
    await assertSucceeds(getDoc(doc(owner, docPath)));
    await assertFails(getDoc(doc(other, docPath)));
    await assertFails(setDoc(doc(other, docPath), valid));
    await assertFails(setDoc(doc(other, 'notificationDevices/user-b'), {...valid, uid:'user-b'}));
    await assertFails(setDoc(doc(owner, docPath), {...valid, guildId:'unknown'}));
    await assertFails(setDoc(doc(owner, docPath), {...valid, notice:false}));
    await assertFails(setDoc(doc(owner, docPath), {...valid, scheduleMinutes:3}));
    await assertFails(setDoc(doc(owner, docPath), {...valid, token:''}));
    await assertSucceeds(setDoc(doc(owner, docPath), {...valid, notice:false, schedule:true}));
    await assertSucceeds(setDoc(doc(owner, docPath), {...valid, notice:false, shield:true, schedule:false,
      shieldEndsAt:'2026-10-10T22:00:00.000Z'}));
    await assertFails(setDoc(doc(owner, 'pushDeliveryLocks/lock-1'), {createdAt:serverTimestamp()}));
    await assertSucceeds(deleteDoc(doc(owner, docPath)));
    console.log('PASS: FCM notice/schedule/shield opt-in, per-user registry, membership and sender lock restrictions');
  } finally {await env.cleanup();}
})().catch(err => {console.error(err);process.exitCode = 1;});
