'use strict';
// Images live as files in assets/ (not inline base64). Every local file the HTML points at must exist.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const assets=path.resolve(__dirname,'..','app/src/main/assets');
const html=fs.readFileSync(path.join(assets,'index.html'),'utf8');
const refs=new Set();
for (const m of html.matchAll(/url\(\s*["']?([^"')]+?\.(?:webp|png|jpe?g|gif|svg))["']?\s*\)/gi)) refs.add(m[1]);
for (const m of html.matchAll(/\ssrc\s*=\s*["']([^"'$]+?\.(?:webp|png|jpe?g|gif|svg|js))["']/gi)) refs.add(m[1]);
// Pre-existing: admin_bg_75.png was never shipped; .admin-feature-manager falls back to its gradient.
const KNOWN_MISSING=new Set(['admin_bg_75.png']);
const local=[...refs].filter(r=>!/^(?:https?:|data:|\/\/)/i.test(r)&&!KNOWN_MISSING.has(r));
assert.ok(local.length>0,'no local asset references found');
for (const r of local) assert.ok(fs.existsSync(path.join(assets,r)),'missing asset: '+r);
console.log('PASS: '+local.length+' local asset references resolve: '+local.join(', '));
