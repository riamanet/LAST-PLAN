'use strict';
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
async function run(){
  const calls=[]; const events=[];
  const context={
    window:{
      LastPlanFirebaseState:{status:'authenticated',uid:'uid-123'},
      LastPlanAndroid:{call:(id,op,payload)=>calls.push({id,op,payload:JSON.parse(payload)})},
      dispatchEvent:event=>events.push(event)
    },
    CustomEvent:class CustomEvent { constructor(type,init){this.type=type;this.detail=init.detail;} },
    Promise, Map, Error, JSON
  };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/firebase-sync.js'),'utf8'),context);
  assert.equal(context.window.LastPlanOnline.ready,true);
  const promise=context.window.LastPlanOnline.createGuild('TKOR','1234','달콩쓰');
  assert.equal(calls[0].op,'createGuild');
  assert.equal(calls[0].payload.code,'1234');
  context.window.LastPlanNativeReply(calls[0].id,{ok:true,guildId:'guild-123'});
  const result=await promise;
  assert.equal(result.guildId,'guild-123');
  const bug=context.window.LastPlanOnline.submitBug({id:'fb_123',content:'테스트',screen:'설정',senderUid:'spoofed'});
  assert.equal(calls[1].op,'submitBug');
  assert.equal(calls[1].payload.senderUid,undefined,'Auth UID must be set natively');
  context.window.LastPlanNativeReply(calls[1].id,{ok:true}); await bug;
  const denied=context.window.LastPlanOnline.setRestriction('gid','uid',true);
  assert.equal(calls[2].op,'setRestriction');
  context.window.LastPlanNativeReply(calls[2].id,{ok:false,message:'permission-denied'});
  await assert.rejects(denied,/permission-denied/);
  context.window.LastPlanNativeEvent({kind:'notices',items:[]});
  assert.equal(events[0].type,'lastplan:online-event');
  console.log('PASS: Firebase bridge operations, callback handling, user UID isolation, event dispatch');
}
run().catch(e=>{console.error(e);process.exit(1)});
