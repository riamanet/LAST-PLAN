/* Copy into a new, locally kept firebase-config.js after creating the project.
   Replace every value with the actual Web App Configuration from Firebase Console.
   This is PUBLIC CLIENT CONFIG, NOT a Firebase Admin SDK secret or service-account key.
   Do not paste any administrator private key here. */
window.LAST_PLAN_FIREBASE_CONFIG = {
  apiKey: "PASTE_WEB_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "PASTE_WEB_APP_ID"
};
