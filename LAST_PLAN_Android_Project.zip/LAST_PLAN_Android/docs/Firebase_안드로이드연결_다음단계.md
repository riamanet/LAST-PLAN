# LAST PLAN Firebase 앱 등록 완료 후 안내

## 확인된 사용자 프로젝트

- Firebase 프로젝트: `last-plan`
- Android 패키지: `com.lastplan.app`
- Android 클라이언트용 구성 파일은 `app/google-services.json`에 설치됨.
- Cloud Firestore 데이터베이스 `(default)` / 서울(asia-northeast3) 생성 확인(사용자 콘솔 화면).
- Firebase Authentication > 익명 인증 사용 설정 확인(사용자 콘솔 화면).

## 이번 버전에 실제로 연결한 것

1. Google Services Gradle 플러그인 4.5.0 및 Firebase Android BoM 34.19.0.
2. `firebase-auth`, `firebase-firestore` SDK 의존성.
3. 앱 시작 시 Firebase 익명 인증. 처음 실행 시 UID 생성, 같은 앱 데이터가 유지되면 이후 세션 재사용.
4. 기존 WebView 디자인/길드 UI는 그대로 유지. native 인증 상태를 `window.LastPlanFirebaseState` 및
   `lastplan:firebase-status` 이벤트로 확인 가능(다음 동기화 구현을 위한 연결 지점).
5. 외부 웹사이트는 Android WebView 내부 대신 외부 브라우저로 열어 인증 정보를 보호하도록 구성.

## 아직 안 된 것 (중요)

- 이 단계는 **Firebase 앱과 Android SDK의 연결** 단계입니다.
- 공유 길드 생성 및 가입, 공지/전광판/일정 데이터의 온라인 읽기·쓰기·실시간 동기화는 아직 연결하지 않았습니다.
- 로컬에서 기존에 만든 길드/일정/공지 데이터를 온라인에 자동 업로드하지 않았습니다.
- `firebase/firestore.rules` 는 프로젝트 안의 초안이며 **실제 콘솔에 게시하지 않았습니다**.
- 익명 사용자는 앱 데이터를 삭제하거나 휴대폰을 변경하면 계정을 복구하기 어려울 수 있습니다.
  길드장·관리자 복구 및 강제 차단은 복구 가능한 인증 방식을 정한 뒤 진행해야 합니다.
- 실제 온라인 공개 전 보안 규칙과 관리자 권한 이전 시나리오를 테스트해야 합니다.

## 다음 사용자 단계

1. Firebase 콘솔에서 Firestore Database > **규칙** 탭으로 이동.
2. **아직 규칙을 게시하지 말고**, 화면을 캡처해 다음 작업을 함께 확인합니다.
3. 개발자는 보안 규칙 초안의 가입·권한 시나리오를 검증하고, 앱의 로컬 데이터를 Firebase 읽기/쓰기로 바꿉니다.
4. Android Studio에서 Gradle Sync 후 앱 실행/인증 상태 확인. 프로젝트에 gradle-wrapper.jar와 gradlew가 없기 때문에
   Android Studio 설치 환경에서 Gradle 동기화가 필요합니다.

주의: Firebase 앱 설정 파일에는 프로젝트 식별 정보가 들어 있으므로 공개 저장소 업로드 전
Android API 키 설정을 확인하세요. 서비스 계정 개인 키/비밀번호는 이 프로젝트에 넣지 마세요.
