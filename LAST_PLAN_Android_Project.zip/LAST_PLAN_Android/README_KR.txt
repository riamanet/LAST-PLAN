LAST PLAN Android v1.0

이 프로젝트는 현재 HTML 기반 길드 일정관리 앱을 Android WebView 앱으로 감싼 설치형 프로젝트입니다.

적용된 내용
- 앱 이름: LAST PLAN
- 패키지명: com.lastplan.app
- 앱 아이콘: 확정한 LAST PLAN 아이콘
- 화면 방향: 세로 고정
- JavaScript / localStorage 활성화
- 기존 HTML 데이터 저장 방식 유지
- 향후 온라인 DB 연결을 위해 INTERNET 권한 포함

중요
현재 데이터는 기존 HTML과 동일하게 각 휴대폰의 앱 내부 저장공간에 저장됩니다.
다른 길드원 휴대폰과 데이터 공유는 이후 온라인 DB 연동 단계에서 추가합니다.

Android Studio에서 빌드
1. 이 폴더를 Android Studio로 엽니다.
2. Gradle Sync를 진행합니다.
3. Build > Build APK(s)를 선택합니다.
4. debug APK 위치: app/build/outputs/apk/debug/app-debug.apk

현재 제작 환경에는 Android SDK가 설치되어 있지 않아 이 ZIP 안에 APK 바이너리 자체는 포함하지 않았습니다.
프로젝트 소스는 APK 빌드가 가능하도록 구성되어 있습니다.


[반응형 레이아웃]
- 로그인/길드생성 화면은 원본 9:16 구도를 유지하면서 기기 비율에 맞게 중앙 배치됩니다.
- 남는 영역은 배경이 자동으로 채워져 고정 비율 검은 여백이 생기지 않습니다.
- 관리자/길드원 화면은 화면 폭·높이에 따라 패딩, 글자, 카드 간격이 자동 조절됩니다.

[2026-10-09 수정 업데이트]
- 자세한 수정내역은 CHANGELOG_20261009.txt 참조
- 로그인 화면 배경 톤다운 이미지: app/src/main/assets/approved-login-muted.png
- 길드명 확정 디자인 렌더러: app/src/main/assets/guild-logo.js
- 키보드 표시 중 화면이 줄어들지 않도록 WebView와 편집창 로직 수정
- 현재는 단말별 데이터 저장 방식입니다. 길드원 건의사항의 다른 기기 전달은 온라인 DB 연동 전까지 지원되지 않습니다.
