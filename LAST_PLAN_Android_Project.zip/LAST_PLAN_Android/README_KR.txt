LAST PLAN Android v1.0

이 프로젝트는 현재 HTML 기반 길드 일정관리 앱을 Android WebView 앱으로 감싼 설치형 프로젝트입니다.

적용된 내용
- 앱 이름: LAST PLAN
- 패키지명: com.lastplan.app
- 앱 아이콘: 확정한 LAST PLAN 아이콘
- 화면 방향: 세로 고정
- JavaScript / localStorage 활성화
- 기존 HTML 데이터 저장 방식 유지
- 향후 온라인 DB 연결을 위해 INTERNET 권한 포함

중요
현재 데이터는 기존 HTML과 동일하게 각 휴대폰의 앱 내부 저장공간에 저장됩니다.
다른 길드원 휴대폰과 데이터 공유는 이후 온라인 DB 연동 단계에서 추가합니다.

Android Studio에서 빌드
1. 이 폴더를 Android Studio로 엽니다.
2. Gradle Sync를 진행합니다.
3. Build > Build APK(s)를 선택합니다.
4. debug APK 위치: app/build/outputs/apk/debug/app-debug.apk

현재 제작 환경에는 Android SDK가 설치되어 있지 않아 이 ZIP 안에 APK 바이너리 자체는 포함하지 않았습니다.
프로젝트 소스는 APK 빌드가 가능하도록 구성되어 있습니다.


[반응형 레이아웃]
- 로그인/길드생성 화면은 원본 9:16 구도를 유지하면서 기기 비율에 맞게 중앙 배치됩니다.
- 남는 영역은 배경이 자동으로 채워져 고정 비율 검은 여백이 생기지 않습니다.
- 관리자/길드원 화면은 화면 폭·높이에 따라 패딩, 글자, 카드 간격이 자동 조절됩니다.


[버전 1.33 수정 안내]
자세한 온라인 연동 조건은 docs/온라인연동_준비사항.md 참고.
운영자 전용 관리 화면 및 실사용 계정 정지 기능은 아직 구현되지 않았습니다.

-----
Firebase 준비 파일: docs/Firebase_데이터베이스_설정.md 참고.
현재 프로젝트는 아직 온라인 DB에 접속하지 않습니다. Firestore 보안 규칙은 firebase/firestore.rules 에 있습니다.


[버전 1.34 · 실제 Firebase Android SDK 등록]
- app/google-services.json 에 Firebase 콘솔에서 내려받은 LAST PLAN Android 설정 파일 포함.
- Google Services Gradle 플러그인과 Firebase Auth/Firestore Android SDK 의존성 추가.
- 앱 시작 시 Firebase 익명 인증 자동 실행; 기존 로컬 길드 로그인 화면은 유지.
- 웹뷰가 내부적으로 lastplan:firebase-status 이벤트로 연결 상태를 확인할 수 있도록 준비.
- **아직 전체 온라인 동기화가 완료된 것은 아닙니다.** 공지·일정·길드 데이터는 기존처럼 로컬에 있습니다.
- Firestore 보안 규칙은 콘솔에서 아직 게시하지 않았으며 안전한 권한 검증 테스트가 필수입니다.
- 다음 작업 안내: docs/Firebase_안드로이드연결_다음단계.md


[v1.36 개발본]
- 온라인 규칙과 구독 충돌 수정 (docs/v1.36_보안규칙검토.md)
- Firebase 규칙 아직 콘솔 게시/에뮬레이터 검증 전. 실제 사용 전 확인 필요.

[v1.38] 안드로이드 홈 화면 통합 위젯 (오늘 일정 / 길드전 / 서바이벌 배틀)
설계 및 주의사항: docs/WIDGET_v1.38_구현안내.txt



[v1.39 알림 개발본]
- 기존 길드 위젯 v1.38 디자인/보호막 수정창 유지
- 안드로이드 일정/보호막 로컬 알림 예약 및 재부팅 후 복원
- Android 13+ 알림 권한 요청, 알림별 ON/OFF 및 5분 간격 안내 유지
- Firebase Cloud Messaging(FCM) 공지 수신 및 알림 토큰 등록 코드 포함
- 별도 Firebase Functions 발송 서버 소스 및 엄격한 알림 토큰 규칙 추가
- 중요: 공지 푸시 서버와 신규 Firestore 규칙은 아직 배포 전입니다.
- 새 규칙에 대해서는 Firestore Emulator 허용/거부 테스트가 필요합니다.
- 전체 안내: docs/PUSH_v1.39_구현안내.txt

[v1.40 원격 푸시(FCM) 개발본]
- 공지/일정/보호막은 Firebase 서버가 FCM으로 발송하도록 준비했습니다.
- 앱 자체 로컬 예약 알람은 사용하지 않습니다.
- Firestore 규칙 검증, Firebase Cloud Functions 배포(Blaze), GitHub APK 빌드와
  실제 휴대폰 테스트가 필요합니다. 배포 전에는 푸시 발송을 보장하지 않습니다.
- 상세: docs/PUSH_v1.40_FCM_배포전확인.txt
