'use strict';
const {createHash} = require('node:crypto');
const NOTICE_WINDOW_MS = 20 * 60 * 1000;
function recentNotice(notice, now) {
  if (!notice || typeof notice.content !== 'string' || !notice.content.trim() ||
      typeof notice.createdAt !== 'string') return false;
  const created = Date.parse(notice.createdAt);
  // Never deliver notifications for old notices or future-dated documents.
  return Number.isFinite(created) && created <= now && now - created < NOTICE_WINDOW_MS;
}
function lockId(uid, identity) {
  return createHash('sha256').update(`${uid}|${identity}`).digest('hex');
}
function validGuildId(id) { return typeof id === 'string' && /^[A-Za-z0-9_-]{1,120}$/.test(id); }
function validDevice(uid, device) {
  return !!device && device.uid === uid && validGuildId(device.guildId) &&
    typeof device.token === 'string' && device.token.length > 0 && device.token.length <= 4096;
}
function inFuture(occurrenceAt, now) { return Number.isFinite(occurrenceAt) && occurrenceAt > now; }
module.exports = {recentNotice, lockId, validGuildId, validDevice, inFuture, NOTICE_WINDOW_MS};
