'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {recentNotice, lockId, validDevice, inFuture} = require('../pure.cjs');
test('only new notices within a short polling window', () => {
  const now = Date.parse('2026-10-10T09:00:00Z');
  assert.equal(recentNotice({content:'공지',createdAt:'2026-10-10T08:45:00Z'}, now), true);
  assert.equal(recentNotice({content:'공지',createdAt:'2026-10-10T07:00:00Z'}, now), false);
  assert.equal(recentNotice({content:'공지',createdAt:'2026-10-10T10:00:00Z'}, now), false);
  assert.equal(recentNotice({content:' ',createdAt:'2026-10-10T08:45:00Z'}, now), false);
});
test('locks stable per recipient and occurrence', () => {
  assert.equal(lockId('abc','notice|A|1'),lockId('abc','notice|A|1'));
  assert.notEqual(lockId('abc','notice|A|1'),lockId('xyz','notice|A|1'));
});
test('only valid device registrations; skip past-due alerts', () => {
  assert.equal(validDevice('u1',{uid:'u1',guildId:'abc_123',token:'fcm'}),true);
  assert.equal(validDevice('u1',{uid:'u2',guildId:'abc_123',token:'fcm'}),false);
  assert.equal(validDevice('u1',{uid:'u1',guildId:'bad/gid',token:'fcm'}),false);
  assert.equal(inFuture(1001,1000),true);
  assert.equal(inFuture(999,1000),false);
});
