'use strict';
/**
 * Optional, best-effort FCM sender on GitHub Actions, no Cloud Functions.
 * Requires a securely stored GitHub Actions secret named LASTPLAN_FIREBASE_SERVICE_ACCOUNT.
 * Notice alerts only: schedule and shield reminders use phone-local AlarmManager.
 * Run only after notificationDevices security rules are deployed and verified.
 */
const {initializeApp, cert} = require('firebase-admin/app');
const {getFirestore, FieldValue} = require('firebase-admin/firestore');
const {getMessaging} = require('firebase-admin/messaging');
const {recentNotice, lockId, validDevice, inFuture, NOTICE_WINDOW_MS} = require('./pure.cjs');

const PROJECT_ID = 'last-plan';
const DRY_RUN = process.env.LASTPLAN_PUSH_DRY_RUN !== 'false';
const now = Date.now();
// Pilot-scale safety limit to protect the daily Spark Firestore reads quota.
const MAX_DEVICES = 25;

function init() {
  const raw = process.env.LASTPLAN_FIREBASE_SERVICE_ACCOUNT;
  if (!raw) throw new Error('Missing GitHub encrypted secret LASTPLAN_FIREBASE_SERVICE_ACCOUNT');
  let serviceAccount;
  try { serviceAccount = JSON.parse(raw); }
  catch { throw new Error('Invalid JSON in LASTPLAN_FIREBASE_SERVICE_ACCOUNT secret'); }
  if (serviceAccount.project_id !== PROJECT_ID || !serviceAccount.client_email || !serviceAccount.private_key) {
    throw new Error('Service account must belong to the LAST PLAN Firebase project.');
  }
  initializeApp({credential: cert(serviceAccount), projectId: PROJECT_ID});
  return getFirestore();
}

async function isMember(db, uid, gid, cache) {
  const key = `${gid}|${uid}`;
  if (!cache.has(key)) {
    const data = await db.doc(`guilds/${gid}/members/${uid}`).get();
    cache.set(key, data.exists);
  }
  return cache.get(key);
}

async function delivery(db, uid, deviceSnap, identity, msg, stats) {
  const data = deviceSnap.data();
  const id = lockId(uid, identity);
  const ref = db.collection('pushDeliveryLocks').doc(id);
  if (DRY_RUN) { stats.preview += 1; return; }
  try {
    await ref.create({createdAt: FieldValue.serverTimestamp(), identityType: msg.kind});
  } catch (error) {
    if (error.code === 6 || error.code === 'already-exists') { stats.duplicates += 1; return; }
    throw error;
  }
  try {
    await getMessaging().send({token: data.token, data: msg,
      android: {priority: 'high', ttl: 3600000}});
    stats.sent += 1;
  } catch (error) {
    const code = error && error.code;
    if (code === 'messaging/registration-token-not-registered' ||
        code === 'messaging/invalid-registration-token') {
      const fresh = await deviceSnap.ref.get();
      if (fresh.exists && fresh.get('token') === data.token) await deviceSnap.ref.delete();
    }
    // Permit retries after transient errors; do not include a token or credentials in logs.
    try { await ref.delete(); } catch { /* retry lock cleanup on maintenance */ }
    stats.failed += 1;
    console.error('FCM error code:', code || 'unknown');
  }
}

async function run() {
  const db = init();
  const stats = {devices: 0, preview: 0, sent: 0, failed: 0, duplicates: 0};
  // Only new-notice recipients are scanned; timed reminders are phone-local.
  const notices = await db.collection('notificationDevices')
    .where('notice', '==', true).limit(MAX_DEVICES + 1).get();
  const devices = new Map(notices.docs.map(d => [d.id, d]));
  stats.devices = devices.size;
  // Hard stop before an unexpectedly large scan on the free-tier plan.
  if (devices.size > MAX_DEVICES) throw new Error('More than 25 devices: stop to protect Spark daily read quota; revise before scaling.');
  const members = new Map();
  const guildNotices = new Map();

  for (const [uid, snap] of devices) {
    const device = snap.data();
    if (!validDevice(uid, device) || !await isMember(db, uid, device.guildId, members)) continue;
    const {guildId} = device;
    const recipient = (identity, message) => delivery(db, uid, snap, identity, message, stats);

    if (device.notice === true) {
      if (!guildNotices.has(guildId)) {
        // Use date-based filtering in code because notice creation timestamps are ISO strings.
        const cutoff = new Date(now - NOTICE_WINDOW_MS).toISOString();
        const list = await db.collection('guilds').doc(guildId)
          .collection('notices').where('createdAt', '>=', cutoff).limit(30).get();
        guildNotices.set(guildId, list.docs.filter(d => recentNotice(d.data(), now)));
      }
      for (const notice of guildNotices.get(guildId)) {
        const data = notice.data();
        const body = data.content.replace(/\s+/g, ' ').trim().slice(0, 120);
        await recipient(`notice|${guildId}|${notice.id}`,
          {kind: 'notice', guildId, noticeId: String(notice.id), body});
      }
    }

  }
  console.log('FCM scan summary (no private tokens logged):', JSON.stringify(stats));
  if (stats.failed) process.exitCode = 1;
}
run().catch(err => { console.error('FCM job failed:', err.message); process.exitCode = 1; });
