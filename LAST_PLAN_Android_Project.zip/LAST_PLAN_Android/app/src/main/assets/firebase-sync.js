/* LAST PLAN Firebase transport — bundled Android app only. No credentials in JS. */
(function () {
  'use strict';
  const pending = new Map();
  let nextId = 1;
  let ready = false;
  const native = window.LastPlanAndroid;
  if (!native || typeof native.call !== 'function') return;

  function call(operation, payload) {
    return new Promise((resolve, reject) => {
      const id = 'r' + nextId++;
      pending.set(id, {resolve, reject});
      try { native.call(id, operation, JSON.stringify(payload || {})); }
      catch (error) { pending.delete(id); reject(error); }
    });
  }
  window.LastPlanNativeReply = function (id, data) {
    const entry = pending.get(id);
    if (!entry) return;
    pending.delete(id);
    if (data && data.ok) entry.resolve(data);
    else entry.reject(new Error((data && data.message) || 'Firebase 요청이 거부되었습니다.'));
  };
  window.LastPlanNativeEvent = function (detail) {
    window.dispatchEvent(new CustomEvent('lastplan:online-event', {detail}));
  };
  window.LastPlanOnline = {
    get ready() { return window.LastPlanFirebaseState?.status === 'authenticated'; },
    get uid() { return window.LastPlanFirebaseState?.uid || ''; },
    createGuild: (name, code, nickname) => call('createGuild', {name, code, nickname}),
    joinGuild: (name, code, nickname) => call('joinGuild', {name, code, nickname}),
    resumeGuild: guildId => call('resumeGuild', {guildId}),
    watchGuild: guildId => call('watchGuild', {guildId}),
    unwatchGuild: () => call('unwatchGuild', {}),
    putDocument: (guildId, kind, id, data) => call('putDocument', {guildId, kind, id, data}),
    deleteDocument: (guildId, kind, id) => call('deleteDocument', {guildId, kind, id}),
    submitSuggestion: report => call('submitSuggestion', {
      guildId: report.guildId, id: report.id, content: report.content
    }),
    submitBug: report => call('submitBug', {
      id: report.id, content: report.content, screen: report.screen || ''
    }),
    setRestriction: (guildId, uid, blocked) => call('setRestriction', {guildId, uid, blocked})
  };
})();
