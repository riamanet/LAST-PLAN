package com.lastplan.app;

import android.Manifest;
import android.os.Build;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;

/** Request Android 13+ notification permission only after the member enables alerts. */
public final class NotificationPermissionBridge {
    public static final int REQUEST_CODE = 1390;
    private final MainActivity activity;
    public NotificationPermissionBridge(MainActivity activity) { this.activity = activity; }

    @JavascriptInterface public void requestPermission() {
        if (Build.VERSION.SDK_INT < 33) return;
        activity.runOnUiThread(() -> {
            if (activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_CODE);
            }
        });
    }
}
