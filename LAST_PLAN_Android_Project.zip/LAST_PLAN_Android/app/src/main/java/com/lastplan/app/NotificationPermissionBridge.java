package com.lastplan.app;

import android.Manifest;
import android.os.Build;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.app.AlarmManager;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.widget.Toast;

/** Request Android 13+ notification permission only after the member enables alerts. */
public final class NotificationPermissionBridge {
    public static final int REQUEST_CODE = 1390;
    private final MainActivity activity;
    private boolean requestExactAfterNotificationGrant = false;
    public NotificationPermissionBridge(MainActivity activity) { this.activity = activity; }

    @JavascriptInterface public void requestTimedReminderPermission() {
        activity.runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 33 && activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                requestExactAfterNotificationGrant = true;
                activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_CODE);
            } else openExactAccessIfNeeded();
        });
    }

    void onPermissionResult(boolean granted) {
        if (granted && requestExactAfterNotificationGrant) openExactAccessIfNeeded();
        requestExactAfterNotificationGrant = false;
    }

    private void openExactAccessIfNeeded() {
        if (Build.VERSION.SDK_INT < 31 || LocalReminderScheduler.exactAlarmsAvailable(activity)) return;
        try {
            Toast.makeText(activity, "정해진 시간에 알림을 받으려면 '알람 및 리마인더'를 허용해 주세요.",
                Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(intent);
        } catch (Exception ignored) {
            // The app still uses an inexact fallback if the OEM hides the settings page.
        }
    }

    @JavascriptInterface public void requestPermission() {
        if (Build.VERSION.SDK_INT < 33) return;
        activity.runOnUiThread(() -> {
            if (activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_CODE);
            }
        });
    }
}
