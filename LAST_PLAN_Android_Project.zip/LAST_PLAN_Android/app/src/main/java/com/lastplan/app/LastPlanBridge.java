package com.lastplan.app;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Android-native Firebase adapter for the packaged (trusted) WebView UI.
 * Only non-privileged operations are exposed. Firestore rules MUST provide
 * the real authorization: browser cache values and role labels are untrusted.
 */
public final class LastPlanBridge {
    private final Activity activity;
    private final WebView webView;
    private final FirebaseAuth auth;
    private final FirebaseFirestore db;
    private final List<ListenerRegistration> listeners = new ArrayList<>();
    private ListenerRegistration suggestionListener;
    private String watchedGuild = "";

    public LastPlanBridge(Activity activity, WebView webView, FirebaseAuth auth, FirebaseFirestore db) {
        this.activity = activity;
        this.webView = webView;
        this.auth = auth;
        this.db = db;
    }

    private static String safe(String s) { return s == null ? "" : s.trim(); }
    private static String nowIso() {
        java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ROOT);
        format.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return format.format(new java.util.Date());
    }
    private static String required(JSONObject o, String key, int max) throws Exception {
        String value = safe(o.optString(key, ""));
        if (value.isEmpty() || value.length() > max) throw new IllegalArgumentException("invalid_" + key);
        return value;
    }
    private static String docId(String value) {
        if (value == null || !value.matches("^[A-Za-z0-9_-]{1,120}$")) throw new IllegalArgumentException("invalid_id");
        return value;
    }
    private static String hashJoin(String name, String code) throws Exception {
        String identity = (name.trim() + "::" + code.trim()).toLowerCase(Locale.ROOT);
        byte[] bytes = MessageDigest.getInstance("SHA-256").digest(identity.getBytes(StandardCharsets.UTF_8));
        StringBuilder out = new StringBuilder();
        for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return out.toString();
    }
    private void runJS(String js) {
        activity.runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }
    private void reply(String id, JSONObject result) {
        runJS("window.LastPlanNativeReply&&window.LastPlanNativeReply(" + JSONObject.quote(id) + "," + result.toString() + ");");
    }
    private void success(String id, JSONObject result) {
        try { result.put("ok", true); } catch (Exception ignored) {}
        reply(id, result);
    }
    private void failure(String id, Exception error) {
        JSONObject response = new JSONObject();
        try {
            response.put("ok", false);
            response.put("error", error.getClass().getSimpleName());
            response.put("message", error.getMessage() == null ? "오류가 발생했습니다." : error.getMessage());
        } catch (Exception ignored) {}
        reply(id, response);
    }
    private FirebaseUser signedIn() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) throw new IllegalStateException("not_authenticated");
        return user;
    }
    private JSONObject membership(String gid, DocumentSnapshot guildDoc, DocumentSnapshot memberDoc) throws Exception {
        if (!memberDoc.exists() || !guildDoc.exists()) throw new IllegalStateException("membership_missing");
        JSONObject o = new JSONObject();
        o.put("guildId", gid);
        o.put("name", safe(guildDoc.getString("name")));
        o.put("uid", signedIn().getUid());
        o.put("role", safe(memberDoc.getString("role")));
        o.put("nickname", safe(memberDoc.getString("nickname")));
        return o;
    }
    private void completeMembership(String req, String gid) {
        String uid = signedIn().getUid();
        db.collection("guilds").document(gid).collection("members").document(uid).get()
            .addOnSuccessListener(member -> db.collection("guilds").document(gid).get()
                .addOnSuccessListener(guild -> {
                    try { success(req, membership(gid, guild, member)); }
                    catch (Exception e) { failure(req, e); }
                }).addOnFailureListener(e -> failure(req, e)))
            .addOnFailureListener(e -> failure(req, e));
    }

    @JavascriptInterface
    public void call(String requestId, String operation, String jsonPayload) {
        // @JavascriptInterface methods run off the UI thread.
        activity.runOnUiThread(() -> {
            try {
                signedIn();
                JSONObject payload = new JSONObject(jsonPayload == null ? "{}" : jsonPayload);
                switch (operation) {
                    case "createGuild": createGuild(requestId, payload); return;
                    case "joinGuild": joinGuild(requestId, payload); return;
                    case "resumeGuild": completeMembership(requestId, docId(required(payload, "guildId", 120))); return;
                    case "watchGuild": watchGuild(requestId, payload); return;
                    case "unwatchGuild": clearListeners(); success(requestId, new JSONObject()); return;
                    case "putDocument": putDocument(requestId, payload); return;
                    case "deleteDocument": deleteDocument(requestId, payload); return;
                    case "submitSuggestion": submitSuggestion(requestId, payload); return;
                    case "submitBug": submitBug(requestId, payload); return;
                    case "setRestriction": setRestriction(requestId, payload); return;
                    default: throw new IllegalArgumentException("unknown_operation");
                }
            } catch (Exception e) { failure(requestId, e); }
        });
    }

    private void createGuild(String req, JSONObject p) throws Exception {
        String name = required(p, "name", 30), code = required(p, "code", 64), nick = required(p, "nickname", 40);
        String uid = signedIn().getUid();
        String joinHash = hashJoin(name, code);
        DocumentReference directory = db.collection("guildDirectory").document(joinHash);
        DocumentReference guild = db.collection("guilds").document();
        String now = nowIso();
        db.runTransaction(tx -> {
            DocumentSnapshot existing = tx.get(directory);
            if (existing.exists()) throw new IllegalStateException("guild_already_exists");
            Map<String, Object> guildData = new HashMap<>();
            guildData.put("name", name); guildData.put("joinCodeHash", joinHash);
            guildData.put("ownerUid", uid); guildData.put("createdAt", now);
            Map<String, Object> dirData = new HashMap<>();
            dirData.put("guildId", guild.getId()); dirData.put("ownerUid", uid); dirData.put("createdAt", now);
            Map<String, Object> member = new HashMap<>();
            member.put("uid", uid); member.put("nickname", nick); member.put("role", "leader");
            member.put("joinCodeHash", joinHash); member.put("joinedAt", now);
            tx.set(guild, guildData);
            tx.set(directory, dirData);
            tx.set(guild.collection("members").document(uid), member);
            return guild.getId();
        }).addOnSuccessListener(gid -> completeMembership(req, gid))
          .addOnFailureListener(e -> failure(req, e));
    }

    private void joinGuild(String req, JSONObject p) throws Exception {
        String name = required(p, "name", 30), code = required(p, "code", 64);
        String nick = safe(p.optString("nickname", "길드원"));
        if (nick.isEmpty() || nick.length() > 40) nick = "길드원";
        String joinHash = hashJoin(name, code), uid = signedIn().getUid();
        final String finalNick = nick;
        db.collection("guildDirectory").document(joinHash).get()
            .addOnSuccessListener(directory -> {
                if (!directory.exists()) { failure(req, new IllegalArgumentException("guild_not_found")); return; }
                String gid = directory.getString("guildId");
                try { docId(gid); } catch (Exception e) { failure(req,e); return; }
                DocumentReference member = db.collection("guilds").document(gid).collection("members").document(uid);
                member.get().addOnSuccessListener(existing -> {
                    if (existing.exists()) { completeMembership(req, gid); return; }
                    Map<String, Object> record = new HashMap<>();
                    record.put("uid", uid); record.put("role", "member");
                    record.put("nickname", finalNick); record.put("joinCodeHash", joinHash);
                    record.put("joinedAt", nowIso());
                    member.set(record).addOnSuccessListener(unused -> completeMembership(req, gid))
                        .addOnFailureListener(e -> failure(req, e));
                }).addOnFailureListener(e -> failure(req, e));
            }).addOnFailureListener(e -> failure(req, e));
    }

    private void emitSnapshot(String gid, String kind, JSONArray items) {
        JSONObject result = new JSONObject();
        try { result.put("guildId", gid); result.put("kind", kind); result.put("items", items); }
        catch (Exception ignored) { return; }
        runJS("window.LastPlanNativeEvent&&window.LastPlanNativeEvent(" + result.toString() + ");");
    }
    private void emitError(String gid, String kind, Exception error) {
        JSONObject result = new JSONObject();
        try { result.put("guildId", gid); result.put("kind", kind); result.put("error", "permission_or_network_error"); }
        catch (Exception ignored) { return; }
        runJS("window.LastPlanNativeEvent&&window.LastPlanNativeEvent(" + result.toString() + ");");
    }
    private void clearListeners() {
        if (suggestionListener != null) {
            suggestionListener.remove();
            suggestionListener = null;
        }
        for (ListenerRegistration listener : listeners) listener.remove();
        listeners.clear(); watchedGuild = "";
    }
    /** Members must not query the anonymous-suggestion inbox: list access is staff-only. */
    private void updateSuggestionSubscription(String gid, String role) {
        if (!gid.equals(watchedGuild)) return;
        if (suggestionListener != null) {
            suggestionListener.remove();
            suggestionListener = null;
        }
        if (!"leader".equals(role) && !"admin".equals(role)) return;
        suggestionListener = db.collection("guilds").document(gid).collection("suggestions")
            .addSnapshotListener((snapshot, error) -> {
                if (!gid.equals(watchedGuild)) return;
                if (error != null) { emitError(gid, "suggestions", error); return; }
                JSONArray items = new JSONArray();
                if (snapshot != null) for (DocumentSnapshot doc : snapshot.getDocuments()) {
                    JSONObject obj = new JSONObject(doc.getData());
                    try { obj.put("id", doc.getId()); } catch (Exception ignored) {}
                    items.put(obj);
                }
                emitSnapshot(gid, "suggestions", items);
            });
    }
    public void shutdown() { clearListeners(); }
    private void watchGuild(String req, JSONObject p) throws Exception {
        String gid = docId(required(p, "guildId", 120));
        clearListeners(); watchedGuild = gid;
        String uid = signedIn().getUid();
        listeners.add(db.collection("guilds").document(gid).collection("members").document(uid)
            .addSnapshotListener((doc, e) -> {
                if (e != null) { emitError(gid, "myRole", e); return; }
                JSONArray items = new JSONArray();
                if (doc != null && doc.exists()) {
                    JSONObject obj = new JSONObject(doc.getData());
                    try { obj.put("id", doc.getId()); } catch (Exception ignored) {}
                    items.put(obj);
                }
                updateSuggestionSubscription(gid, doc != null && doc.exists() ? doc.getString("role") : "");
                emitSnapshot(gid, "myRole", items);
            }));
        listeners.add(db.collection("guilds").document(gid).collection("suggestionRestrictions").document(uid)
            .addSnapshotListener((doc, e) -> {
                if (e != null) { emitError(gid, "myRestriction", e); return; }
                JSONArray items = new JSONArray();
                if (doc != null && doc.exists()) items.put(new JSONObject(doc.getData()));
                emitSnapshot(gid, "myRestriction", items);
            }));
        for (String kind : new String[]{"notices", "events"}) {
            listeners.add(db.collection("guilds").document(gid).collection(kind)
                .addSnapshotListener((snapshot, e) -> {
                    if (e != null) { emitError(gid, kind, e); return; }
                    JSONArray items = new JSONArray();
                    if (snapshot != null) for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        JSONObject obj = new JSONObject(doc.getData());
                        try { obj.put("id", doc.getId()); } catch (Exception ignored) {}
                        items.put(obj);
                    }
                    emitSnapshot(gid, kind, items);
                }));
        }
        // Rules permit reads of billboard/current only, not unrestricted lists.
        listeners.add(db.collection("guilds").document(gid).collection("billboard").document("current")
            .addSnapshotListener((doc, e) -> {
                if (e != null) { emitError(gid, "billboard", e); return; }
                JSONArray items = new JSONArray();
                if (doc != null && doc.exists()) {
                    JSONObject obj = new JSONObject(doc.getData());
                    try { obj.put("id", "current"); } catch (Exception ignored) {}
                    items.put(obj);
                }
                emitSnapshot(gid, "billboard", items);
            }));
        success(req, new JSONObject());
    }
    private DocumentReference scopedDocument(JSONObject p, boolean billboardAllowed) throws Exception {
        String guildId = docId(required(p, "guildId", 120));
        String kind = required(p, "kind", 30);
        if (!kind.equals("notices") && !kind.equals("events") && !(billboardAllowed && kind.equals("billboard")))
            throw new IllegalArgumentException("invalid_collection");
        String itemId = docId(required(p, "id", 120));
        if (kind.equals("billboard") && !itemId.equals("current")) throw new IllegalArgumentException("invalid_billboard_id");
        return db.collection("guilds").document(guildId).collection(kind).document(itemId);
    }
    private static Map<String,Object> asMap(JSONObject object) throws Exception {
        HashMap<String,Object> result = new HashMap<>();
        for (java.util.Iterator<String> keys = object.keys(); keys.hasNext();) {
            String key = keys.next();
            Object v = object.get(key);
            if (v instanceof String || v instanceof Boolean || v instanceof Integer || v instanceof Long || v instanceof Double)
                result.put(key, v);
            else if (v == JSONObject.NULL) continue;
            else throw new IllegalArgumentException("unsupported_data_shape");
        }
        return result;
    }
    private void putDocument(String req, JSONObject p) throws Exception {
        DocumentReference ref = scopedDocument(p, true);
        Map<String,Object> data = asMap(p.getJSONObject("data"));
        data.remove("senderUid"); data.remove("ownerUid"); data.remove("role");
        if (data.isEmpty() || data.size() > 30) throw new IllegalArgumentException("invalid_document");
        ref.set(data).addOnSuccessListener(unused -> success(req, new JSONObject()))
            .addOnFailureListener(e -> failure(req, e));
    }
    private void deleteDocument(String req, JSONObject p) throws Exception {
        DocumentReference ref = scopedDocument(p, false);
        ref.delete().addOnSuccessListener(unused -> success(req, new JSONObject()))
            .addOnFailureListener(e -> failure(req, e));
    }
    private void submitSuggestion(String req, JSONObject p) throws Exception {
        String gid = docId(required(p, "guildId", 120));
        String content = required(p, "content", 1000);
        String id = docId(required(p, "id", 120));
        Map<String,Object> data = new HashMap<>();
        data.put("content", content); data.put("senderUid", signedIn().getUid());
        data.put("createdAt", nowIso()); data.put("status", "pending");
        db.collection("guilds").document(gid).collection("suggestions").document(id).set(data)
            .addOnSuccessListener(unused -> success(req, new JSONObject()))
            .addOnFailureListener(e -> failure(req, e));
    }
    private void submitBug(String req, JSONObject p) throws Exception {
        String content = required(p, "content", 1000);
        String id = docId(required(p, "id", 120));
        String screen = safe(p.optString("screen", ""));
        Map<String,Object> data = new HashMap<>();
        data.put("content", content); data.put("senderUid", signedIn().getUid());
        data.put("createdAt", nowIso());
        data.put("status", "pending"); data.put("screen", screen.length() > 100 ? screen.substring(0,100) : screen);
        db.collection("bugReports").document(id).set(data)
            .addOnSuccessListener(unused -> success(req, new JSONObject()))
            .addOnFailureListener(e -> failure(req, e));
    }
    private void setRestriction(String req, JSONObject p) throws Exception {
        String gid = docId(required(p, "guildId", 120));
        String uid = docId(required(p, "uid", 120));
        boolean blocked = p.optBoolean("blocked", false);
        Map<String,Object> data = new HashMap<>();
        data.put("blocked", blocked); data.put("reason", "부적절한 건의사항");
        data.put("actorUid", signedIn().getUid());
        data.put("updatedAt", nowIso());
        db.collection("guilds").document(gid).collection("suggestionRestrictions").document(uid).set(data)
            .addOnSuccessListener(unused -> success(req, new JSONObject()))
            .addOnFailureListener(e -> failure(req, e));
    }
}
