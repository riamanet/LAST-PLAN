package com.lastplan.app;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

/** Receives remote FCM data messages for new guild notices only. */
public final class LastPlanMessagingService extends FirebaseMessagingService {
    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        NotificationDeviceRegistry.refresh(this);
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);
        String kind = message.getData().get("kind");
        // Timed reminders must be delivered by this phone, not a delayed server cron.
        if (!"notice".equals(kind)) return;
        JSONObject snapshot = new WidgetStore(this).snapshot();
        JSONObject choices = snapshot.optJSONObject("notifications");
        if (choices == null || !choices.optBoolean(kind, false)) return;
        String gid = message.getData().get("guildId");
        if (gid == null || !gid.equals(snapshot.optString("pushGuildId", ""))) return;
        String body = message.getData().get("body");
        if (body == null || body.trim().isEmpty()) return;
        NotificationDisplay.show(this, "LAST PLAN · 새 공지", body, kind);
    }
}
