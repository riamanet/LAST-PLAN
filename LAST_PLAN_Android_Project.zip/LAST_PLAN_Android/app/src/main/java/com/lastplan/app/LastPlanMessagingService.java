package com.lastplan.app;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

/** Receives remote FCM data messages for all three opted-in notification types. */
public final class LastPlanMessagingService extends FirebaseMessagingService {
    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        NotificationDeviceRegistry.refresh(this);
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);
        String kind = message.getData().get("kind");
        if (!"notice".equals(kind) && !"schedule".equals(kind) && !"shield".equals(kind)) return;
        JSONObject snapshot = new WidgetStore(this).snapshot();
        JSONObject choices = snapshot.optJSONObject("notifications");
        if (choices == null || !choices.optBoolean(kind, false)) return;
        String gid = message.getData().get("guildId");
        if (gid == null || !gid.equals(snapshot.optString("pushGuildId", ""))) return;
        if ("schedule".equals(kind) || "shield".equals(kind)) {
            String raw = message.getData().get("minutes");
            int current = choices.optInt(kind + "Minutes", 10);
            if (raw == null || !String.valueOf(current).equals(raw)) return;
        }
        String body = message.getData().get("body");
        if (body == null || body.trim().isEmpty()) return;
        String title;
        if ("notice".equals(kind)) title = "LAST PLAN · 새 공지";
        else if ("shield".equals(kind)) title = "LAST PLAN · 보호막 종료 알림";
        else title = "LAST PLAN · 길드 일정 알림";
        NotificationDisplay.show(this, title, body, kind);
    }
}
