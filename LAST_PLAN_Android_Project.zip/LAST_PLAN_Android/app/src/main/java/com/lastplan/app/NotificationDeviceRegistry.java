package com.lastplan.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Registers opted-in FCM recipients and private reminder preferences.
 * No Firebase Admin credentials or message-sending privileges live in this APK.
 */
public final class NotificationDeviceRegistry {
    private static final String TAG = "LastPlanFCM";
    private static final String LOCAL_PREFS = "lastplan_fcm_registry";
    private NotificationDeviceRegistry() { }

    private static int minutes(JSONObject settings, String field) {
        int v = settings.optInt(field, 10);
        return v >= 5 && v <= 30 && v % 5 == 0 ? v : 10;
    }

    private static String shieldEndsAt(JSONObject snapshot) {
        JSONObject shield = snapshot.optJSONObject("shieldTimer");
        if (shield == null || !shield.optBoolean("active", false)
            || !shield.optBoolean("confirmed", false)) return "";
        String iso = shield.optString("endsAt", "");
        return iso.length() <= 40 && iso.matches("^\\d{4}-\\d\\d-\\d\\dT.*Z$") ? iso : "";
    }

    public static void refresh(Context context) {
        Context application = context.getApplicationContext();
        FirebaseUser user;
        try { user = FirebaseAuth.getInstance().getCurrentUser(); }
        catch (IllegalStateException e) { return; }
        if (user == null) return;
        String uid = user.getUid();
        JSONObject snapshot = new WidgetStore(application).snapshot();
        JSONObject settings = snapshot.optJSONObject("notifications");
        String guildId = snapshot.optString("pushGuildId", "");
        boolean notice = settings != null && settings.optBoolean("notice", false);
        boolean schedule = settings != null && settings.optBoolean("schedule", false);
        boolean shield = settings != null && settings.optBoolean("shield", false);
        SharedPreferences local = application.getSharedPreferences(LOCAL_PREFS, Context.MODE_PRIVATE);
        if (guildId.isEmpty() || !(notice || schedule || shield)) {
            // Do not leave a stale token subscribed if the user disables all alerts,
            // signs out, or leaves their guild.
            if (local.getString("registered", "").isEmpty()) return;
            FirebaseFirestore.getInstance().collection("notificationDevices").document(uid)
                .delete().addOnSuccessListener(unused -> local.edit().remove("registered").apply())
                .addOnFailureListener(e -> Log.w(TAG, "FCM device unsubscribe pending", e));
            return;
        }
        int scheduleMinutes = minutes(settings, "scheduleMinutes");
        int shieldMinutes = minutes(settings, "shieldMinutes");
        String endsAt = shieldEndsAt(snapshot);
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token -> {
            // A different guild/member may have become active while the token loaded.
            JSONObject fresh = new WidgetStore(application).snapshot();
            JSONObject opts = fresh.optJSONObject("notifications");
            if (opts == null || !guildId.equals(fresh.optString("pushGuildId", "")) ||
                notice != opts.optBoolean("notice", false) ||
                schedule != opts.optBoolean("schedule", false) ||
                shield != opts.optBoolean("shield", false) ||
                scheduleMinutes != minutes(opts, "scheduleMinutes") ||
                shieldMinutes != minutes(opts, "shieldMinutes") ||
                !endsAt.equals(shieldEndsAt(fresh))) return;
            String fingerprint = uid + "|" + guildId + "|" + token + "|" + notice + "|" + schedule
                + "|" + shield + "|" + scheduleMinutes + "|" + shieldMinutes + "|" + endsAt;
            if (fingerprint.equals(local.getString("registered", ""))) return;
            Map<String, Object> doc = new HashMap<>();
            doc.put("uid", uid);
            doc.put("guildId", guildId);
            doc.put("token", token);
            doc.put("notice", notice);
            doc.put("schedule", schedule);
            doc.put("shield", shield);
            doc.put("scheduleMinutes", scheduleMinutes);
            doc.put("shieldMinutes", shieldMinutes);
            doc.put("shieldEndsAt", endsAt);
            doc.put("updatedAt", FieldValue.serverTimestamp());
            FirebaseFirestore.getInstance().collection("notificationDevices").document(uid)
                .set(doc).addOnSuccessListener(unused -> local.edit()
                    .putString("registered", fingerprint).apply())
                .addOnFailureListener(e -> Log.w(TAG, "FCM registration requires v1.40 Firestore rules", e));
        }).addOnFailureListener(e -> Log.w(TAG, "FCM token unavailable", e));
    }
}
