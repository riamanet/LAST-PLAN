package com.lastplan.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Small native dialog launched directly from the widget, no main-screen navigation. */
public class WidgetShieldActivity extends Activity {
    private static final int GOLD = Color.rgb(200,173,121);
    private static final int TEXT = Color.rgb(232,213,175);
    private static final TimeZone KST = TimeZone.getTimeZone("Asia/Seoul");
    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");
    private WidgetStore widgetStore;
    private NumberPicker hourPicker, minutePicker;
    private RadioGroup choices;
    private TextView endLabel;
    private long endMillis;
    private final int[] durations = {8,12,24};

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable border() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.rgb(25,35,52));
        d.setCornerRadius(dp(8));
        d.setStroke(dp(1), GOLD);
        return d;
    }

    private TextView label(String title, int size) {
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(TEXT);
        t.setTextSize(size);
        return t;
    }

    private TextView separator() {
        TextView t = label(":", 23);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        widgetStore = new WidgetStore(this);
        JSONObject signedIn = widgetStore.snapshot();
        if (signedIn.optString("guildName", "").trim().isEmpty()) {
            Toast.makeText(this, "로그인 후 보호막을 설정해 주세요.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        getWindow().setLayout(getResources().getDisplayMetrics().widthPixels - dp(28), -2);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(25,35,52));
        root.setPadding(dp(20), dp(20), dp(20), dp(18));
        setContentView(root);

        TextView title = label("보호막 설정", 19);
        title.setTypeface(null, 1);
        root.addView(title);
        TextView subtitle = label("보호막 지속시간", 13);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(-1,-2);
        labelParams.topMargin = dp(18);
        root.addView(subtitle, labelParams);

        choices = new RadioGroup(this);
        choices.setOrientation(RadioGroup.HORIZONTAL);
        for (int duration : durations) {
            RadioButton radio = new RadioButton(this);
            radio.setId(duration);
            radio.setText(duration + "시간");
            radio.setTextSize(15);
            radio.setTextColor(Color.WHITE);
            radio.setButtonTintList(android.content.res.ColorStateList.valueOf(GOLD));
            choices.addView(radio, new RadioGroup.LayoutParams(0,dp(48),1));
        }
        root.addView(choices);
        TextView timeTitle = label("보호막 남은 시간 (게임에서 확인)",13);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1,-2);
        titleParams.topMargin=dp(8);
        root.addView(timeTitle,titleParams);

        LinearLayout pickers = new LinearLayout(this);
        pickers.setOrientation(LinearLayout.HORIZONTAL);
        pickers.setGravity(Gravity.CENTER);
        hourPicker = new NumberPicker(this);
        hourPicker.setMinValue(0);
        hourPicker.setMaxValue(24);
        hourPicker.setWrapSelectorWheel(false);
        hourPicker.setFormatter(value -> String.format(Locale.ROOT,"%02d",value));
        minutePicker = new NumberPicker(this);
        minutePicker.setMinValue(0);
        minutePicker.setMaxValue(59);
        minutePicker.setWrapSelectorWheel(false);
        minutePicker.setFormatter(value -> String.format(Locale.ROOT,"%02d",value));
        pickers.addView(hourPicker, new LinearLayout.LayoutParams(0,dp(130),1));
        pickers.addView(separator(), new LinearLayout.LayoutParams(dp(20),dp(130)));
        pickers.addView(minutePicker, new LinearLayout.LayoutParams(0,dp(130),1));
        root.addView(pickers);

        endLabel = label("",14);
        endLabel.setGravity(Gravity.CENTER);
        endLabel.setPadding(dp(6),dp(8),dp(6),dp(10));
        endLabel.setBackgroundColor(Color.rgb(38,51,73));
        root.addView(endLabel, new LinearLayout.LayoutParams(-1,-2));

        LinearLayout actions = new LinearLayout(this);
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(-1,dp(44));
        actionParams.topMargin=dp(15);
        root.addView(actions,actionParams);
        Button cancel = new Button(this);
        cancel.setAllCaps(false);
        cancel.setText("취소");
        cancel.setTextColor(TEXT);
        cancel.setTextSize(14);
        cancel.setBackground(border());
        Button save = new Button(this);
        save.setAllCaps(false);
        save.setText("저장하기");
        save.setTextColor(TEXT);
        save.setTextSize(14);
        save.setBackground(border());
        LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,-1,1);
        a.rightMargin=dp(6);
        actions.addView(cancel,a);
        LinearLayout.LayoutParams b=new LinearLayout.LayoutParams(0,-1,1);
        b.leftMargin=dp(6);
        actions.addView(save,b);

        int chosenDuration=8;
        long remainingMs = 8L * 3600000L;
        JSONObject timer=widgetStore.snapshot().optJSONObject("shieldTimer");
        if (timer != null && timer.optBoolean("active")) {
            int saved = timer.optInt("baseHours",8);
            if (saved==8 || saved==12 || saved==24) chosenDuration=saved;
            try {
                SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.ROOT);
                f.setTimeZone(UTC);
                Date endDate=f.parse(timer.optString("endsAt",""));
                if(endDate!=null) remainingMs=Math.max(60000L,endDate.getTime()-System.currentTimeMillis());
            } catch (Exception ignored) { }
        }
        long minutesLeft=Math.max(1,(remainingMs+59999L)/60000L);
        minutesLeft = Math.min(24L*60L, minutesLeft);
        hourPicker.setValue((int)(minutesLeft/60));
        minutePicker.setValue((int)(minutesLeft%60));
        choices.check(chosenDuration);
        hourPicker.setOnValueChangedListener((v,oldVal,newVal)->updateEnd());
        minutePicker.setOnValueChangedListener((v,oldVal,newVal)->updateEnd());
        choices.setOnCheckedChangeListener((group,checkedId)->updateEnd());
        cancel.setOnClickListener(v->finish());
        save.setOnClickListener(v->save());
        updateEnd();
    }

    private long remainingMillis() {
        return (hourPicker.getValue()*60L+minutePicker.getValue()) * 60000L;
    }

    private void updateEnd() {
        endMillis=System.currentTimeMillis()+remainingMillis();
        SimpleDateFormat f=new SimpleDateFormat("M월 d일 HH:mm",Locale.KOREAN);
        f.setTimeZone(KST);
        endLabel.setText(remainingMillis()<60000L
          ? "남은 시간을 1분 이상 선택해 주세요."
          : "예상 종료 · " + f.format(new Date(endMillis)));
    }

    private static String iso(long ms) {
        SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.ROOT);
        f.setTimeZone(UTC);
        return f.format(new Date(ms));
    }

    private void save() {
        updateEnd();
        if (widgetStore.snapshot().optString("guildName", "").trim().isEmpty()) {
            Toast.makeText(this, "로그인 후 보호막을 설정해 주세요.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        if (remainingMillis() < 60000L) {
            Toast.makeText(this,"남은 시간을 1분 이상 선택해 주세요.",Toast.LENGTH_LONG).show();
            return;
        }
        try {
            int selected=choices.getCheckedRadioButtonId();
            int hours=selected==24 ? 24 : selected==12 ? 12:8;
            JSONObject timer=new JSONObject();
            timer.put("active",true);
            timer.put("confirmed",true);
            timer.put("baseHours",hours);
            timer.put("startAt",iso(endMillis-hours*3600000L));
            timer.put("endsAt",iso(endMillis));
            timer.put("lastUpdated",iso(System.currentTimeMillis()));
            widgetStore.saveFromWidget(timer);
            Toast.makeText(this,"보호막 시간이 저장됐어요.",Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception e) {
            Toast.makeText(this,"저장에 실패했어요.",Toast.LENGTH_LONG).show();
        }
    }
}
