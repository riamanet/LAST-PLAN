package com.lastplan.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.util.TypedValue;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Native resizeable home-screen widget; tabs never launch the application. */
public class LastPlanWidgetProvider extends AppWidgetProvider {
    private static final String ACTION_TAB = "com.lastplan.app.WIDGET_TAB";
    private static final String ACTION_REFRESH = "com.lastplan.app.WIDGET_REFRESH";
    private static final String PREFS = "lastplan_widget_tabs";
    private static final TimeZone KST = TimeZone.getTimeZone("Asia/Seoul");
    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");
    private static final long HOUR = 3600000L;

    private static class Row {
        final String time;
        final String text;
        Row(String time, String text) { this.time = time; this.text = text; }
    }

    static void refreshAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, LastPlanWidgetProvider.class));
        if (ids.length == 0) return;
        for (int id : ids) render(context, manager, id);
        scheduleNextRefresh(context);
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) render(context, manager, id);
        scheduleNextRefresh(context);
    }

    @Override public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                                      int id, Bundle options) {
        render(context, manager, id);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_TAB.equals(intent.getAction())) {
            int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);
            int tab = intent.getIntExtra("tab", 0);
            if (id >= 0 && tab >= 0 && tab <= 2) {
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putInt("tab_" + id, tab).apply();
                render(context, AppWidgetManager.getInstance(context), id);
            }
        } else if (ACTION_REFRESH.equals(intent.getAction())
                || Intent.ACTION_TIME_CHANGED.equals(intent.getAction())
                || Intent.ACTION_TIMEZONE_CHANGED.equals(intent.getAction())) {
            refreshAll(context);
        }
    }

    @Override public void onDeleted(Context context, int[] ids) {
        for (int id : ids) context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove("tab_" + id).apply();
    }

    private static PendingIntent tabIntent(Context c, int id, int tab) {
        Intent i = new Intent(c, LastPlanWidgetProvider.class).setAction(ACTION_TAB);
        i.setData(Uri.parse("lastplan://widget/" + id + "/tab/" + tab));
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        i.putExtra("tab", tab);
        return PendingIntent.getBroadcast(c, id * 5 + tab, i,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent activityIntent(Context c, int id, boolean shield) {
        Intent i = new Intent(c, shield ? WidgetShieldActivity.class : MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.setAction(shield ? "com.lastplan.app.EDIT_WIDGET_SHIELD" : "com.lastplan.app.OPEN_FROM_WIDGET");
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        return PendingIntent.getActivity(c, id * 5 + (shield ? 3 : 4), i,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static String gameKey(long ms) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
        f.setTimeZone(UTC);
        return f.format(new Date(ms - 2 * HOUR));
    }

    private static int gameDay(long ms) {
        Calendar c = Calendar.getInstance(UTC);
        c.setTimeInMillis(ms - 2 * HOUR);
        return c.get(Calendar.DAY_OF_WEEK) - 1; // Sunday 0, Saturday 6
    }

    private static long parseDay(String day) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
            f.setLenient(false); f.setTimeZone(UTC);
            return f.parse(day).getTime();
        } catch (Exception e) { return -1; }
    }

    private static boolean occurs(JSONObject event, String day) {
        String begin = event.optString("date", "");
        if (day.equals(begin)) return true;
        long startMs = parseDay(begin), targetMs = parseDay(day);
        if (startMs < 0 || targetMs < startMs) return false;
        long difference = (targetMs - startMs) / 86400000L;
        int interval = Math.max(1, event.optInt("repeatInterval", 1));
        String repeat = event.optString("repeat", "none");
        if ("daily".equals(repeat)) return difference % interval == 0;
        return "weekly".equals(repeat) && difference % 7 == 0 && (difference / 7) % interval == 0;
    }

    private static long hiddenAt(JSONObject event, String gameDate) {
        if (!event.optBoolean("autoHide", false)) return Long.MAX_VALUE;
        String time = event.optString("time", "");
        if (!time.matches("[0-2][0-9]:[0-5][0-9]")) return Long.MAX_VALUE;
        try {
            String[] hhmm = time.split(":");
            int hour = Integer.parseInt(hhmm[0]);
            int minute = Integer.parseInt(hhmm[1]);
            if (hour > 23) return Long.MAX_VALUE;
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT);
            f.setTimeZone(KST);
            f.setLenient(false);
            // 00:00-10:59 belongs to the following civil day of this game day.
            Calendar base = Calendar.getInstance(KST);
            base.setTime(f.parse(gameDate + " " + time));
            if (hour < 11) base.add(Calendar.DAY_OF_MONTH, 1);
            return base.getTimeInMillis() + Math.max(1, event.optInt("autoHideHours", 1)) * HOUR;
        } catch (Exception e) { return Long.MAX_VALUE; }
    }

    private static long shieldEnds(JSONObject shield) {
        if (shield == null || !shield.optBoolean("active") || !shield.optBoolean("confirmed")) return 0;
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ROOT);
            f.setTimeZone(UTC);
            Date parsed = f.parse(shield.optString("endsAt", ""));
            return parsed == null ? 0 : parsed.getTime();
        } catch (Exception error) { return 0; }
    }

    private static List<Row> getRows(Context context, JSONObject snapshot, int tab, long now) {
        List<Row> rows = new ArrayList<>();
        String date = gameKey(now);
        int day = gameDay(now);
        if (tab == 0) {
            long end = shieldEnds(snapshot.optJSONObject("shieldTimer"));
            if (end > now) {
                long minutes = Math.max(1, (end - now + 59999) / 60000);
                rows.add(new Row("보호막", (minutes / 60) + "시간 " + (minutes % 60) + "분 남음"));
            }
            JSONArray events = snapshot.optJSONArray("events");
            if (events == null) return rows;
            String completionDate = snapshot.optString("completionDate", "");
            JSONArray done = date.equals(completionDate) ? snapshot.optJSONArray("completed") : null;
            for (int i = 0; i < events.length(); i++) {
                JSONObject event = events.optJSONObject(i);
                if (event == null || !occurs(event, date) || hiddenAt(event, date) <= now) continue;
                String title = event.optString("title", "").trim();
                if (title.isEmpty() || isCompleted(done, title)) continue;
                rows.add(new Row(event.optString("time", "시간 미정"), title));
            }
            // Shield always stays first; all other entries are chronological.
            int offset = end > now ? 1 : 0;
            rows.subList(offset, rows.size()).sort((a,b) -> a.time.compareTo(b.time));
        } else {
            JSONObject all = new WidgetStore(context).commonData();
            JSONObject today = all.optJSONObject(String.valueOf(day));
            if (today == null) return rows;
            JSONArray items = today.optJSONArray(tab == 1 ? "tasks" : "survival");
            if (items == null) return rows;
            for (int i = 0; i < items.length(); i++) {
                if (tab == 1) {
                    String task = items.optString(i, "");
                    if (task.contains("보호막 필수")) {
                        long ends = shieldEnds(snapshot.optJSONObject("shieldTimer"));
                        if (ends > now) {
                            long mins = Math.max(1, (ends - now + 59999L) / 60000L);
                            task += " · " + (mins / 60) + "시간 " + (mins % 60) + "분 남음";
                        }
                    }
                    rows.add(new Row("•", task));
                }
                else {
                    JSONArray slot = items.optJSONArray(i);
                    if (slot != null) rows.add(new Row(slot.optString(0, ""), slot.optString(1, "")));
                }
            }
        }
        return rows;
    }

    private static boolean isCompleted(JSONArray completed, String title) {
        if (completed == null) return false;
        for (int i = 0; i < completed.length(); i++) if (title.equals(completed.optString(i))) return true;
        return false;
    }

    static void render(Context context, AppWidgetManager manager, int id) {
        JSONObject snapshot = new WidgetStore(context).snapshot();
        int tab = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("tab_" + id, 0);
        long now = System.currentTimeMillis();
        boolean shieldActive = shieldEnds(snapshot.optJSONObject("shieldTimer")) > now;
        boolean showShield = (tab == 0 && shieldActive) || (tab == 1 && gameDay(now) == 6);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_last_plan);
        String theme = WidgetAppearance.theme(context);
        int font = WidgetAppearance.scale(context);
        float factor = new float[]{0.86f, 1.0f, 1.16f, 1.32f}[font];
        int bg = "navy".equals(theme) ? R.drawable.widget_background_navy
            : "silver".equals(theme) ? R.drawable.widget_background_silver
            : "ivory".equals(theme) ? R.drawable.widget_background_ivory
            : R.drawable.widget_background_gold;
        int active = "navy".equals(theme) ? R.drawable.widget_tab_active_navy
            : "silver".equals(theme) ? R.drawable.widget_tab_active_silver
            : "ivory".equals(theme) ? R.drawable.widget_tab_active_ivory
            : R.drawable.widget_tab_active_gold;
        int inactive = "navy".equals(theme) ? R.drawable.widget_tab_inactive_navy
            : "silver".equals(theme) ? R.drawable.widget_tab_inactive_silver
            : "ivory".equals(theme) ? R.drawable.widget_tab_inactive_ivory
            : R.drawable.widget_tab_inactive_gold;
        int action = "navy".equals(theme) ? R.drawable.widget_action_gold_navy
            : "silver".equals(theme) ? R.drawable.widget_action_gold_silver
            : "ivory".equals(theme) ? R.drawable.widget_action_gold_ivory
            : R.drawable.widget_action_gold_gold;
        int primary = Color.parseColor("ivory".equals(theme) ? "#2E271E" : "#F4F4F4");
        int accent = Color.parseColor("navy".equals(theme) ? "#8AC8E9" : "silver".equals(theme) ? "#D0D5DE"
            : "ivory".equals(theme) ? "#806333" : "#DCC18A");
        int secondary = Color.parseColor("ivory".equals(theme) ? "#574C3D" : "#DCDCDC");
        views.setInt(R.id.widget_card, "setBackgroundResource", bg);
        views.setTextColor(R.id.widget_header, accent);
        views.setTextViewTextSize(R.id.widget_header, TypedValue.COMPLEX_UNIT_SP, 16f*factor);
        for (int rid : new int[]{R.id.widget_shield, R.id.widget_open_app}) {
            views.setTextViewTextSize(rid, TypedValue.COMPLEX_UNIT_SP, 12.5f*factor);
            views.setTextColor(rid, accent);
            views.setInt(rid, "setBackgroundResource", action);
        }
        String guildName = snapshot.optString("guildName", "");
        views.setTextViewText(R.id.widget_header, guildName.isEmpty() ? "LAST PLAN" : "LAST PLAN · " + guildName);
        int[] tabs = {R.id.widget_tab_today, R.id.widget_tab_guild, R.id.widget_tab_survival};
        for (int i = 0; i < tabs.length; i++) {
            views.setInt(tabs[i], "setBackgroundResource", i == tab ? active : inactive);
            views.setTextColor(tabs[i], i == tab ? accent : secondary);
            views.setTextViewTextSize(tabs[i], TypedValue.COMPLEX_UNIT_SP, 13f*factor);
            views.setOnClickPendingIntent(tabs[i], tabIntent(context, id, i));
        }
        Bundle opts = manager.getAppWidgetOptions(id);
        int width = opts == null ? 250 : opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
        int height = opts == null ? 150 : opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 150);
        // On narrow widgets, short action labels keep both buttons fully visible.
        boolean compact = width < 250;
        views.setViewVisibility(R.id.widget_shield, showShield ? View.VISIBLE : View.GONE);
        if (showShield) {
            views.setTextViewText(R.id.widget_shield,
                compact ? (shieldActive ? "수정" : "보호막")
                        : (shieldActive ? "보호막 수정" : "보호막 설정"));
            views.setOnClickPendingIntent(R.id.widget_shield, activityIntent(context, id, true));
        }
        views.setTextViewText(R.id.widget_open_app, compact ? "앱 열기" : "앱으로 이동");
        views.setOnClickPendingIntent(R.id.widget_open_app, activityIntent(context, id, false));
        // Account for header, tabs, footer and padding. The card itself uses
        // wrap_content, so a single event no longer leaves a huge empty panel.
        // Still respect the size of the launcher cell on smaller widgets.
        int capacity = Math.max(1, Math.min(12, (int)((height - 116 - 18*(factor-1f)) / (39f*factor))));
        List<Row> rows = getRows(context, snapshot, tab, now);
        views.removeAllViews(R.id.widget_rows);
        if (rows.isEmpty()) {
            rows.add(new Row("", tab == 0 && guildName.isEmpty() ? "앱에서 길드에 접속해 주세요." : "오늘은 일정이 없습니다."));
        }
        int count = Math.min(capacity, rows.size());
        for (int i = 0; i < count; i++) {
            Row row = rows.get(i);
            int rowLayout = tab == 1 ? R.layout.widget_row_guild
                : tab == 2 ? R.layout.widget_row_survival : R.layout.widget_row;
            RemoteViews child = new RemoteViews(context.getPackageName(), rowLayout);
            // A separator belongs BETWEEN items; the last row has no bottom rule.
            child.setViewVisibility(R.id.widget_row_divider,
                i == count - 1 ? View.INVISIBLE : View.VISIBLE);
            child.setTextViewText(R.id.widget_row_time, row.time);
            child.setTextViewText(R.id.widget_row_title, row.text);
            child.setTextColor(R.id.widget_row_time, accent);
            child.setTextColor(R.id.widget_row_title, primary);
            child.setTextViewTextSize(R.id.widget_row_time, TypedValue.COMPLEX_UNIT_SP,
                (tab == 2 ? 12.5f : tab == 1 ? 16f : 14f) * factor);
            child.setTextViewTextSize(R.id.widget_row_title, TypedValue.COMPLEX_UNIT_SP, 16f * factor);
            // No PendingIntent for schedule rows: accidental taps should do nothing.
            views.addView(R.id.widget_rows, child);
        }
        manager.updateAppWidget(id, views);
    }

    private static void scheduleNextRefresh(Context context) {
        JSONObject snapshot = new WidgetStore(context).snapshot();
        long now = System.currentTimeMillis();
        Calendar nextReset = Calendar.getInstance(KST);
        nextReset.set(Calendar.HOUR_OF_DAY, 11);
        nextReset.set(Calendar.MINUTE, 0);
        nextReset.set(Calendar.SECOND, 5);
        nextReset.set(Calendar.MILLISECOND, 0);
        if (nextReset.getTimeInMillis() <= now) nextReset.add(Calendar.DAY_OF_MONTH, 1);
        long next = nextReset.getTimeInMillis();
        long shieldEnd = shieldEnds(snapshot.optJSONObject("shieldTimer"));
        if (shieldEnd > now) {
            next = Math.min(next, shieldEnd + 1000);
            // Home widget countdowns update approximately once per minute.
            long minuteBoundary = (now / 60000L + 1L) * 60000L + 1500L;
            next = Math.min(next, minuteBoundary);
        }
        JSONArray events = snapshot.optJSONArray("events");
        if (events != null) {
            String date = gameKey(now);
            for (int i = 0; i < events.length(); i++) {
                JSONObject event = events.optJSONObject(i);
                if (event != null && occurs(event, date)) {
                    long hide = hiddenAt(event, date);
                    if (hide > now && hide < next) next = hide + 1000;
                }
            }
        }
        Intent i = new Intent(context, LastPlanWidgetProvider.class).setAction(ACTION_REFRESH);
        PendingIntent pending = PendingIntent.getBroadcast(context, 7993, i,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms != null) alarms.set(AlarmManager.RTC, next, pending);
    }
}
