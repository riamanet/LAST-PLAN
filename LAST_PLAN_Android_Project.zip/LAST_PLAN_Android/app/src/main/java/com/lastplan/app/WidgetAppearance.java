package com.lastplan.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import org.json.JSONObject;

/** Device-local widget appearance; independent of signed-in account. */
public final class WidgetAppearance {
    private static final String STORE = "lastplan_widget_appearance_v146";
    private final Context app;
    public WidgetAppearance(Context context) { app = context.getApplicationContext(); }
    private SharedPreferences prefs() { return app.getSharedPreferences(STORE, Context.MODE_PRIVATE); }
    static int scale(Context context) { return Math.max(0, Math.min(3, context.getSharedPreferences(STORE, Context.MODE_PRIVATE).getInt("font", 1))); }
    static String theme(Context context) {
        String t = context.getSharedPreferences(STORE, Context.MODE_PRIVATE).getString("theme", "gold");
        return ("navy".equals(t) || "silver".equals(t) || "ivory".equals(t)) ? t : "gold";
    }
    @JavascriptInterface public String get() {
        return "{\"font\":" + scale(app) + ",\"theme\":\"" + theme(app) + "\"}";
    }
    @JavascriptInterface public void set(String raw) {
        if (raw == null || raw.length() > 256) return;
        try {
            JSONObject value = new JSONObject(raw);
            int font = value.optInt("font", 1);
            String theme = value.optString("theme", "gold");
            if (font < 0 || font > 3 || !("gold".equals(theme) || "navy".equals(theme) || "silver".equals(theme) || "ivory".equals(theme))) return;
            prefs().edit().putInt("font", font).putString("theme", theme).apply();
            LastPlanWidgetProvider.refreshAll(app);
        } catch (Exception ignored) { }
    }
}
