package com.lastplan.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** A minimal receiver for one-shot, device-local exact/inexact alarms. */
public final class LocalReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        if (LocalReminderScheduler.ACTION_SCHEDULE.equals(intent.getAction()))
            LocalReminderScheduler.onAlarm(context, "schedule");
        else if (LocalReminderScheduler.ACTION_SHIELD.equals(intent.getAction()))
            LocalReminderScheduler.onAlarm(context, "shield");
    }
}
