package com.lastplan.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Log;
import org.json.JSONObject;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private WebView webView;
    private FirebaseAuth auth;
    private FirebaseFirestore firestore;
    private LastPlanBridge onlineBridge;
    private boolean appPageReady = false;
    private String firebaseStatus = "starting";
    private String firebaseUid = "";

    /**
     * Communicates only a non-sensitive connection state to our packaged HTML.
     * No ID token or privileged credentials are passed to the WebView.
     */
    private void updateFirebaseStatus(String status, String uid) {
        firebaseStatus = status;
        firebaseUid = uid == null ? "" : uid;
        if (!appPageReady || webView == null) return;
        final JSONObject payload = new JSONObject();
        try {
            payload.put("status", firebaseStatus);
            payload.put("uid", firebaseUid);
            payload.put("projectId", "last-plan");
        } catch (Exception ignored) {
            return;
        }
        final String js = "(function(){window.LastPlanFirebaseState=" + payload.toString()
            + ";window.dispatchEvent(new CustomEvent('lastplan:firebase-status',"
            + "{detail:window.LastPlanFirebaseState}));})();";
        webView.post(() -> {
            if (webView != null && appPageReady) webView.evaluateJavascript(js, null);
        });
    }

    /** Firebase Auth uses its saved anonymous user on subsequent launches. */
    private void startFirebase() {
        try {
            FirebaseApp firebaseApp = FirebaseApp.initializeApp(this);
            if (firebaseApp == null) {
                updateFirebaseStatus("not_configured", "");
                return;
            }
            auth = FirebaseAuth.getInstance(firebaseApp);
            firestore = FirebaseFirestore.getInstance(firebaseApp);
            onlineBridge = new LastPlanBridge(this, webView, auth, firestore);
            webView.addJavascriptInterface(onlineBridge, "LastPlanAndroid");
            FirebaseUser alreadySignedIn = auth.getCurrentUser();
            if (alreadySignedIn != null) {
                updateFirebaseStatus("authenticated", alreadySignedIn.getUid());
                NotificationDeviceRegistry.refresh(this);
                return;
            }
            updateFirebaseStatus("authenticating", "");
            auth.signInAnonymously().addOnCompleteListener(this, task -> {
                if (task.isSuccessful() && auth.getCurrentUser() != null) {
                    updateFirebaseStatus("authenticated", auth.getCurrentUser().getUid());
                    NotificationDeviceRegistry.refresh(this);
                } else {
                    Log.w("LAST_PLAN", "Firebase anonymous authentication failed", task.getException());
                    updateFirebaseStatus("auth_error", "");
                }
            });
        } catch (Exception error) {
            Log.e("LAST_PLAN", "Firebase initialization failed", error);
            updateFirebaseStatus("initialization_error", "");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        getWindow().setStatusBarColor(Color.rgb(5, 7, 11));
        getWindow().setNavigationBarColor(Color.rgb(5, 7, 11));

        final FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5, 7, 11));

        webView = new NoExtractUiWebView(this);
        webView.setBackgroundColor(Color.rgb(5, 7, 11));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        // The widget's device-local cache is independent of Firebase connectivity.
        webView.addJavascriptInterface(new WidgetStore(this), "LastPlanWidget");
        webView.addJavascriptInterface(new NotificationPermissionBridge(this), "LastPlanNotifications");
        NotificationDisplay.ensureChannel(this);

        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
        root.addView(webView, webParams);
        setContentView(root);

        /*
         * Android 15/16 can draw apps edge-to-edge by default.  Keep the WebView
         * inside the real status/navigation-bar safe area so the 9:16 login
         * composition is not hidden behind system UI and the footer remains visible.
         */
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int topInset = insets.getSystemWindowInsetTop();
            int bottomInset = insets.getSystemWindowInsetBottom();
            int leftInset = insets.getSystemWindowInsetLeft();
            int rightInset = insets.getSystemWindowInsetRight();

            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) webView.getLayoutParams();
            if (lp.topMargin != topInset || lp.bottomMargin != bottomInset
                    || lp.leftMargin != leftInset || lp.rightMargin != rightInset) {
                lp.topMargin = topInset;
                lp.bottomMargin = bottomInset;
                lp.leftMargin = leftInset;
                lp.rightMargin = rightInset;
                webView.setLayoutParams(lp);
            }
            return insets;
        });
        root.requestApplyInsets();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                // Keep the internal UI on bundled assets. External web links open
                // in the user's browser instead of replacing our trusted page.
                if ("file".equals(scheme) && "file:///android_asset/index.html".equals(uri.toString())) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException | SecurityException ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                appPageReady = url != null && url.startsWith("file:///android_asset/index.html");
                if (appPageReady) updateFirebaseStatus(firebaseStatus, firebaseUid);
                if (appPageReady) webView.evaluateJavascript(
                    "window.dispatchEvent(new Event('lastplan:widget-resume'));", null);
            }
        });

        startFirebase();
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        NotificationDeviceRegistry.refresh(this);
        // Apply edits made in the native widget dialog back to the existing
        // personal shield timer after returning to the app.
        if (appPageReady && webView != null) webView.evaluateJavascript(
            "window.dispatchEvent(new Event('lastplan:widget-resume'));", null);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NotificationPermissionBridge.REQUEST_CODE && grantResults.length > 0
            && grantResults[0] != android.content.pm.PackageManager.PERMISSION_GRANTED && webView != null) {
            webView.evaluateJavascript("window.dispatchEvent(new Event('lastplan:notification-denied'));", null);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        appPageReady = false;
        if (onlineBridge != null) onlineBridge.shutdown();
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }


    private static class NoExtractUiWebView extends WebView {
        public NoExtractUiWebView(Context context) {
            super(context);
        }

        public NoExtractUiWebView(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        @Override
        public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
            InputConnection ic = super.onCreateInputConnection(outAttrs);
            if (outAttrs != null) {
                outAttrs.imeOptions |= EditorInfo.IME_FLAG_NO_EXTRACT_UI;
                outAttrs.imeOptions |= EditorInfo.IME_FLAG_NO_FULLSCREEN;
            }
            return ic;
        }
    }
}
