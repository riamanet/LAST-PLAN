package com.lastplan.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Per-device schedule and shield reminders. These do NOT need GitHub/FCM.
 * AlarmManager may fall back to an inexact alarm until Android grants exact-alarm access.
 * A reminder on this device can only reflect guild data most recently synced to this device.
 */
public final class LocalReminderScheduler {
    static final String ACTION_SCHEDULE = "com.lastplan.app.REMIND_SCHEDULE";
    static final String ACTION_SHIELD = "com.lastplan.app.REMIND_SHIELD";
    private static final String TAG = "LastPlanReminders";
    private static final String PREFS = "lastplan_local_reminders";
    private static final String[] TYPES = {"schedule", "shield"};
    private static final TimeZone KST = TimeZone.getTimeZone("Asia/Seoul");
    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");
    private static final long MINUTE = 60000L;
    private static final long DAY = 86400000L;
    private static final long HOUR = 3600000L;
    private static final long ALLOW_LATE_MS = 120000L;

    private LocalReminderScheduler() { }

    static boolean exactAlarmsAvailable(Context context) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return manager != null && manager.canScheduleExactAlarms();
    }

    private static PendingIntent alarmIntent(Context context, String type) {
        Intent intent = new Intent(context, LocalReminderReceiver.class)
            .setAction("schedule".equals(type) ? ACTION_SCHEDULE : ACTION_SHIELD);
        return PendingIntent.getBroadcast(context, "schedule".equals(type) ? 7101 : 7102, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void cancel(Context context, String type) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.cancel(alarmIntent(context, type));
    }

    private static boolean enabled(JSONObject snapshot, String type) {
        JSONObject settings = snapshot.optJSONObject("notifications");
        return settings != null && settings.optBoolean(type, false);
    }

    private static int minutes(JSONObject snapshot, String type) {
        JSONObject settings = snapshot.optJSONObject("notifications");
        int n = settings == null ? 10 : settings.optInt(type + "Minutes", 10);
        return n >= 5 && n <= 30 && n % 5 == 0 ? n : 10;
    }

    private static long parseIso(String iso) {
        if (iso == null || iso.isEmpty()) return 0;
        // The WebView and the widget dialog both generate UTC ISO timestamps.
        for (String pattern : new String[]{"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'"}) {
            try {
                SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.ROOT);
                format.setTimeZone(UTC);
                format.setLenient(false);
                Date date = format.parse(iso);
                if (date != null) return date.getTime();
            } catch (Exception ignored) { }
        }
        return 0;
    }

    private static long shieldTarget(JSONObject snapshot) {
        JSONObject timer = snapshot.optJSONObject("shieldTimer");
        if (timer == null || !timer.optBoolean("active") || !timer.optBoolean("confirmed")) return 0;
        long end = parseIso(timer.optString("endsAt", ""));
        return end <= 0 ? 0 : end - minutes(snapshot, "shield") * MINUTE;
    }

    private static long dayStartUtc(String key) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
            format.setTimeZone(UTC);
            format.setLenient(false);
            Date date = format.parse(key);
            return date == null ? -1 : date.getTime();
        } catch (Exception ignored) { return -1; }
    }

    private static String gameKey(long now) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
        format.setTimeZone(UTC);
        // Korea's 11 AM reset is 02:00 UTC.
        return format.format(new Date(now - 2 * HOUR));
    }

    private static String addGameDays(String day, int count) {
        long ms = dayStartUtc(day);
        if (ms < 0) return "";
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
        format.setTimeZone(UTC);
        return format.format(new Date(ms + count * DAY));
    }

    private static boolean occurs(JSONObject event, String day) {
        String start = event.optString("date", "");
        long from = dayStartUtc(start), to = dayStartUtc(day);
        if (from < 0 || to < from) return false;
        long days = (to - from) / DAY;
        if (days == 0) return true;
        int interval = Math.max(1, event.optInt("repeatInterval", 1));
        String repeat = event.optString("repeat", "none");
        if ("daily".equals(repeat)) return days % interval == 0;
        return "weekly".equals(repeat) && days % 7 == 0 && (days / 7) % interval == 0;
    }

    private static long occurrence(JSONObject event, String day) {
        if (!occurs(event, day)) return 0;
        String time = event.optString("time", "");
        if (!time.matches("(?:[01]\\d|2[0-3]):[0-5]\\d")) return 0;
        int hour = Integer.parseInt(time.substring(0, 2));
        int minute = Integer.parseInt(time.substring(3));
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT);
            format.setTimeZone(KST);
            format.setLenient(false);
            Date date = format.parse(day + " " + time);
            if (date == null) return 0;
            return date.getTime() + (hour < 11 ? DAY : 0);
        } catch (Exception ignored) { return 0; }
    }

    private static final class Next {
        final long when;
        final String message;
        Next(long when, String message) { this.when = when; this.message = message; }
    }

    private static Next nextSchedule(JSONObject snapshot, long now) {
        JSONArray events = snapshot.optJSONArray("events");
        if (events == null || snapshot.optString("guildName", "").isEmpty()) return null;
        int ahead = minutes(snapshot, "schedule");
        long best = Long.MAX_VALUE;
        String bestText = "";
        String gameDay = gameKey(now);
        // Include next-day rollover and recurring events. Never trigger a missed alert on first install.
        for (int delta = -1; delta <= 35; delta++) {
            String day = addGameDays(gameDay, delta);
            for (int i = 0; i < Math.min(events.length(), 300); i++) {
                JSONObject event = events.optJSONObject(i);
                if (event == null) continue;
                String title = event.optString("title", "").trim();
                if (title.isEmpty()) continue;
                long eventTime = occurrence(event, day);
                long reminder = eventTime - ahead * MINUTE;
                if (eventTime <= now || reminder <= now + 2000L || reminder >= best) continue;
                best = reminder;
                bestText = title.substring(0, Math.min(90, title.length()));
            }
        }
        if (best == Long.MAX_VALUE) return null;
        // If multiple events share a reminder moment, mention all those at the same time.
        int grouped = 0;
        for (int delta = -1; delta <= 35; delta++) {
            String day = addGameDays(gameDay, delta);
            for (int i = 0; i < Math.min(events.length(), 300); i++) {
                JSONObject event = events.optJSONObject(i);
                if (event == null || event.optString("title", "").trim().isEmpty()) continue;
                if (occurrence(event, day) - ahead * MINUTE == best) grouped++;
            }
        }
        String message = grouped > 1 ? bestText + " 외 " + (grouped - 1) + "개 일정 · " + ahead + "분 전"
            : bestText + " · " + ahead + "분 전";
        return new Next(best, message);
    }

    /** Synchronizes alarms after local settings, a WebView Firebase sync, boot, and time change. */
    public static synchronized void reconcile(Context context) {
        Context app = context.getApplicationContext();
        JSONObject snapshot = new WidgetStore(app).snapshot();
        SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        AlarmManager manager = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        for (String type : TYPES) {
            cancel(app, type);
            long now = System.currentTimeMillis();
            Next next = null;
            if (enabled(snapshot, type)) {
                if ("shield".equals(type)) {
                    long target = shieldTarget(snapshot);
                    if (target > now + 2000L) {
                        next = new Next(target, "보호막이 " + minutes(snapshot, "shield") + "분 후 종료됩니다.");
                    }
                } else next = nextSchedule(snapshot, now);
            }
            if (next == null) {
                prefs.edit().remove("time_" + type).remove("body_" + type).apply();
                continue;
            }
            prefs.edit().putLong("time_" + type, next.when)
                .putString("body_" + type, next.message).apply();
            try {
                if (Build.VERSION.SDK_INT >= 23) {
                    if (exactAlarmsAvailable(app)) manager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP, next.when, alarmIntent(app, type));
                    else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.when,
                        alarmIntent(app, type));
                } else manager.setExact(AlarmManager.RTC_WAKEUP, next.when, alarmIntent(app, type));
            } catch (SecurityException error) {
                Log.w(TAG, "Exact alarm access unavailable; scheduling an inexact fallback", error);
                if (Build.VERSION.SDK_INT >= 23) manager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP, next.when, alarmIntent(app, type));
                else manager.set(AlarmManager.RTC_WAKEUP, next.when, alarmIntent(app, type));
            }
        }
    }

    static synchronized void onAlarm(Context context, String type) {
        Context app = context.getApplicationContext();
        if (!"shield".equals(type) && !"schedule".equals(type)) return;
        SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long target = prefs.getLong("time_" + type, 0);
        long now = System.currentTimeMillis();
        JSONObject snapshot = new WidgetStore(app).snapshot();
        // Ignore cancelled, stale, or very late alarms rather than misleading members.
        if (target > 0 && enabled(snapshot, type) && now >= target - 2000L &&
                now - target <= ALLOW_LATE_MS && target != prefs.getLong("delivered_" + type, 0)) {
            prefs.edit().putLong("delivered_" + type, target).apply();
            String title = "shield".equals(type) ? "LAST PLAN · 보호막 종료 알림" :
                "LAST PLAN · 길드 일정 알림";
            NotificationDisplay.show(app, title, prefs.getString("body_" + type, ""), type);
        }
        reconcile(app);
    }
}
