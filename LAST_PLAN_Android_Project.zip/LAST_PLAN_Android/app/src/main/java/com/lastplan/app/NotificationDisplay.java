package com.lastplan.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;

/** Native notification presentation for remote Firebase Cloud Messaging events. */
public final class NotificationDisplay {
    private static final String CHANNEL = "lastplan_notifications_v1";
    private NotificationDisplay() { }

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "LAST PLAN 알림",
                NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("길드 일정, 새 공지사항, 보호막 종료 알림");
            NotificationManager manager = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    public static void show(Context context, String title, String message, String kind) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(
            Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        ensureChannel(context);
        Intent open = new Intent(context, MainActivity.class);
        open.setAction("com.lastplan.app.OPEN_NOTIFICATION");
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap = PendingIntent.getActivity(context, 0, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder notification = new NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_lastplan_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(tap)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManager manager = (NotificationManager)
            context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify((kind + ":" + title + ":" + message)
            .hashCode() & 0x7fffffff, notification.build());
    }
}
