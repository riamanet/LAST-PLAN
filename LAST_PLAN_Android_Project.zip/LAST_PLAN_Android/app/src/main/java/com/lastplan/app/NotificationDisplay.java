package com.lastplan.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;

/** Independent OS notification channels for each notice type and sound preference. */
public final class NotificationDisplay {
    private NotificationDisplay() { }
    private static final String[] KINDS = {"notice", "schedule", "shield"};
    private static final String[] MODES = {"sound", "vibrate", "silent"};
    private static String name(String kind) {
        return "notice".equals(kind) ? "공지사항" : "shield".equals(kind) ? "보호막" : "일정";
    }
    private static String channel(String kind, String mode) {
        return "lastplan_" + kind + "_" + mode + "_v146";
    }
    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        for (String kind : KINDS) for (String mode : MODES) {
            NotificationChannel ch = new NotificationChannel(channel(kind, mode),
                "LAST PLAN · " + name(kind) + ("sound".equals(mode) ? " (소리+진동)" : "vibrate".equals(mode) ? " (진동)" : " (무음)"),
                "silent".equals(mode) ? NotificationManager.IMPORTANCE_LOW : NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("LAST PLAN " + name(kind) + " 알림 방식");
            ch.enableVibration(!"silent".equals(mode));
            if ("vibrate".equals(mode) || "silent".equals(mode)) ch.setSound(null, null);
            else ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
            manager.createNotificationChannel(ch);
        }
    }
    public static void show(Context context, String title, String message, String kind) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(
            Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        if (!"notice".equals(kind) && !"schedule".equals(kind) && !"shield".equals(kind)) return;
        ensureChannel(context);
        JSONObject settings = new WidgetStore(context).snapshot().optJSONObject("notifications");
        String mode = settings == null ? "sound" : settings.optString(kind + "Mode", "sound");
        if (!"sound".equals(mode) && !"vibrate".equals(mode) && !"silent".equals(mode)) mode = "sound";
        Intent open = new Intent(context, MainActivity.class);
        open.setAction("com.lastplan.app.OPEN_NOTIFICATION");
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap = PendingIntent.getActivity(context, 0, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder notification = new NotificationCompat.Builder(context, channel(kind, mode))
            .setSmallIcon(R.drawable.ic_lastplan_notification)
            .setContentTitle(title).setContentText(message)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(tap).setAutoCancel(true)
            .setPriority("silent".equals(mode) ? NotificationCompat.PRIORITY_LOW : NotificationCompat.PRIORITY_DEFAULT);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            notification.setDefaults("sound".equals(mode) ? 3 : "vibrate".equals(mode) ? 2 : 0);
        }
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify((kind + ":" + title + ":" + message)
            .hashCode() & 0x7fffffff, notification.build());
    }
}
