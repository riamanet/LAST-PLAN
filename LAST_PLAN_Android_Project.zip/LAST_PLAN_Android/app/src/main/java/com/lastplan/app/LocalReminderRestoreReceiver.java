package com.lastplan.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restore per-device alarms after reboot, app upgrade or local clock changes. */
public final class LocalReminderRestoreReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
            || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
            || Intent.ACTION_TIME_CHANGED.equals(action)
            || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            LocalReminderScheduler.reconcile(context);
            // Rebuild RemoteViews on package update, reboot, and clock changes.
            // This replaces stale launcher-side widget layouts without deleting widgets.
            LastPlanWidgetProvider.refreshAll(context);
        }
    }
}
