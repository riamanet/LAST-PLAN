package com.lastplan.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** A per-device mirror of the signed-in WebView's schedule and shield timer. */
public final class WidgetStore {
    private static final String PREFS = "lastplan_widget_data";
    private static final String SNAPSHOT = "snapshot";
    private static final String PENDING_SHIELD = "pending_shield";
    private final Context application;

    public WidgetStore(Context context) { application = context.getApplicationContext(); }

    private SharedPreferences prefs() { return application.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    public JSONObject snapshot() {
        try { return new JSONObject(prefs().getString(SNAPSHOT, "{}")); }
        catch (Exception ignored) { return new JSONObject(); }
    }

    /** Called only from the bundled trusted HTML through the app's JS bridge. */
    @JavascriptInterface public void sync(String raw) {
        try {
            if (raw == null || raw.length() > 180000) return;
            JSONObject next = new JSONObject(raw);
            if (!next.has("guildName") || !next.has("events")) return;
            if (prefs().contains(PENDING_SHIELD)) {
                // A just-edited widget timer wins until WebView consumes it.
                JSONObject previous = snapshot();
                next.put("shieldTimer", previous.optJSONObject("shieldTimer"));
            }
            String json = next.toString();
            if (TextUtils.equals(json, prefs().getString(SNAPSHOT, ""))) return;
            prefs().edit().putString(SNAPSHOT, json).apply();
            LastPlanWidgetProvider.refreshAll(application);
            LocalReminderScheduler.reconcile(application);
            NotificationDeviceRegistry.refresh(application);
        } catch (Exception ignored) { }
    }

    @JavascriptInterface public String consumePendingShield() {
        String raw = prefs().getString(PENDING_SHIELD, "");
        if (!raw.isEmpty()) prefs().edit().remove(PENDING_SHIELD).apply();
        return raw;
    }

    public void saveFromWidget(JSONObject timer) {
        JSONObject next = snapshot();
        try { next.put("shieldTimer", timer); }
        catch (Exception ignored) { return; }
        prefs().edit().putString(SNAPSHOT, next.toString())
            .putString(PENDING_SHIELD, timer.toString()).apply();
        LastPlanWidgetProvider.refreshAll(application);
        LocalReminderScheduler.reconcile(application);
        NotificationDeviceRegistry.refresh(application);
    }

    public JSONObject commonData() {
        try (InputStream stream = application.getAssets().open("widget-common.json")) {
            byte[] bytes = new byte[stream.available()];
            int off = 0;
            while (off < bytes.length) {
                int n = stream.read(bytes, off, bytes.length - off);
                if (n < 0) break;
                off += n;
            }
            return new JSONObject(new String(bytes, 0, off, StandardCharsets.UTF_8));
        } catch (Exception e) { return new JSONObject(); }
    }
}
