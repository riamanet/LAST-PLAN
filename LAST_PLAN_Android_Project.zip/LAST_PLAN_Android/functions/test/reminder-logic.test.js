'use strict';
const assert = require('node:assert/strict');
const {test} = require('node:test');
const {kstGameDay, occurrence, dueSchedule, dueShield} = require('../reminder-logic');
const at = iso => Date.parse(iso);

test('KST game day rolls over at 11:00, not midnight', () => {
  assert.equal(kstGameDay(at('2026-10-10T01:59:00Z')), '2026-10-09');
  assert.equal(kstGameDay(at('2026-10-10T02:00:00Z')), '2026-10-10');
});
test('one-off Korean-time schedule triggers at chosen lead', () => {
  const event = {id:'a', title:'비약쟁탈전', date:'2026-10-10', time:'20:00', repeat:'none', repeatInterval:1};
  assert.equal(occurrence(event,'2026-10-10'), at('2026-10-10T11:00:00Z'));
  assert.equal(dueSchedule([event], 10, at('2026-10-10T10:50:30Z')).length, 1);
  assert.equal(dueSchedule([event], 10, at('2026-10-10T10:49:00Z')).length, 0);
});
test('after-midnight game-day schedule occurs on following calendar date', () => {
  const e = {id:'early',title:'심야',date:'2026-10-10',time:'01:00',repeat:'none',repeatInterval:1};
  assert.equal(occurrence(e,'2026-10-10'), at('2026-10-10T16:00:00Z'));
  assert.equal(dueSchedule([e], 5, at('2026-10-10T15:55:05Z')).length, 1);
});
test('weekly repeat does not run on the wrong weekday or interval', () => {
  const e = {id:'w',title:'길드전',date:'2026-10-10',time:'20:00',repeat:'weekly',repeatInterval:2};
  assert.equal(occurrence(e,'2026-10-17'),null);
  assert.notEqual(occurrence(e,'2026-10-24'),null);
});
test('shield alert only in the configured window', () => {
  assert.ok(dueShield('2026-10-10T12:00:00.000Z',30,at('2026-10-10T11:30:02Z')));
  assert.equal(dueShield('2026-10-10T12:00:00.000Z',20,at('2026-10-10T11:30:02Z')),null);
  assert.equal(dueShield('2026-10-10T12:00:00.000Z',7,at('2026-10-10T11:30:02Z')),null);
});
