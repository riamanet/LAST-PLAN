'use strict';

const {onDocumentCreated} = require('firebase-functions/v2/firestore');
const {initializeApp} = require('firebase-admin/app');
const {getFirestore, FieldValue} = require('firebase-admin/firestore');
const {getMessaging} = require('firebase-admin/messaging');
const {createHash} = require('node:crypto');

initializeApp();
const REGION = 'asia-northeast3';

async function currentMember(store, uid, guildId) {
  if (!uid || !guildId || !/^[A-Za-z0-9_-]{1,120}$/.test(guildId)) return false;
  const doc = await store.doc(`guilds/${guildId}/members/${uid}`).get();
  return doc.exists;
}

async function sendWithCleanup(store, recipient, data) {
  try {
    await getMessaging().send({
      token: recipient.token,
      data,
      android: {priority: 'high', ttl: 3600000}
    });
    return true;
  } catch (error) {
    const code = error && error.code;
    if (code === 'messaging/registration-token-not-registered' ||
        code === 'messaging/invalid-registration-token') {
      // Remove only the token that actually failed. New registrations must survive.
      const fresh = await recipient.ref.get();
      if (fresh.exists && fresh.get('token') === recipient.token) await recipient.ref.delete();
    } else {
      console.error('FCM delivery error:', code || 'unknown');
    }
    return false;
  }
}

/**
 * Reserve one send per user + occurrence, so scheduled executions and retries
 * do not create duplicate pushes. Cloud Functions have at-least-once semantics.
 */
async function sendOnce(store, recipient, identity, data) {
  const id = createHash('sha256').update(`${recipient.uid}|${identity}`).digest('hex');
  const lockRef = store.collection('pushDeliveryLocks').doc(id);
  try { await lockRef.create({createdAt: FieldValue.serverTimestamp()}); }
  catch (e) { if (e.code === 6 || e.code === 'already-exists') return; throw e; }
  const sent = await sendWithCleanup(store, recipient, data);
  if (!sent) {
    // In case of an intermittent network error the next scheduled run can retry.
    // Invalid tokens will already have been removed from the device collection.
    try { await lockRef.delete(); } catch (error) { console.error('Lock cleanup failed', error); }
  }
}

/** Immediate server-side notice push (not called from untrusted clients). */
exports.notifyNewGuildNotice = onDocumentCreated({
  document: 'guilds/{guildId}/notices/{noticeId}', region: REGION
}, async event => {
  if (!event.data) return;
  const {guildId, noticeId} = event.params;
  const notice = event.data.data() || {};
  if (typeof notice.content !== 'string' || !notice.content.trim()) return;
  const body = notice.content.replace(/\s+/g, ' ').trim().slice(0, 120);
  const store = getFirestore();
  // One-field guildId filter avoids requiring a composite index.
  const devices = await store.collection('notificationDevices').where('guildId', '==', guildId).get();
  for (const doc of devices.docs) {
    const candidate = doc.data();
    if (candidate.uid !== doc.id || !candidate.notice || typeof candidate.token !== 'string') continue;
    if (!await currentMember(store, doc.id, guildId)) continue;
    await sendOnce(store, {uid: doc.id, token: candidate.token, ref: doc.ref},
      `notice|${guildId}|${noticeId}`,
      {kind: 'notice', guildId, noticeId: String(noticeId), body});
  }
});

/**
 * Important: schedule/shield alarms are now native per-device AlarmManager alarms.
 * No Cloud Scheduler reminder function is exported, to prevent duplicate alerts.
 * This optional, undeployed Cloud Function sends ONLY new notices and needs Blaze.
 */
