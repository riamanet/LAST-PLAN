'use strict';

/** Pure game-day/FCM reminder time calculations. Korea (UTC+09) has no DST. */
const DAY_MS = 86400000;
const KST_OFFSET_MS = 9 * 3600000;
const GAME_RESET_HOUR = 11;
const WINDOW_MS = 10 * 60000; // tolerate a briefly late scheduler run
const pad = value => String(value).padStart(2, '0');

function kstGameDay(nowMs) {
  return new Date(nowMs + KST_OFFSET_MS - GAME_RESET_HOUR * 3600000)
    .toISOString().slice(0, 10);
}
function addDay(dateKey, offset) {
  const base = Date.parse(`${dateKey}T00:00:00Z`);
  return new Date(base + offset * DAY_MS).toISOString().slice(0, 10);
}
function dueInWindow(ms, nowMs) {
  return Number.isFinite(ms) && ms <= nowMs && nowMs - ms < WINDOW_MS;
}
function validMinutes(minutes) {
  return Number.isInteger(minutes) && minutes >= 5 && minutes <= 30 && minutes % 5 === 0;
}
function occurrence(event, gameDate) {
  if (!event || typeof event.date !== 'string' ||
      !/^\d{4}-\d{2}-\d{2}$/.test(event.date) ||
      !/^([01]\d|2[0-3]):[0-5]\d$/.test(event.time || '')) return null;
  const begin = Date.parse(`${event.date}T00:00:00Z`);
  const candidate = Date.parse(`${gameDate}T00:00:00Z`);
  if (!Number.isFinite(begin) || !Number.isFinite(candidate)) return null;
  const days = Math.round((candidate - begin) / DAY_MS);
  if (days < 0) return null;
  const repeat = event.repeat || 'none';
  const interval = Number.isInteger(event.repeatInterval) && event.repeatInterval > 0
    ? event.repeatInterval : 1;
  if (days !== 0) {
    if (repeat === 'daily' && days % interval !== 0) return null;
    if (repeat === 'weekly' && (days % 7 !== 0 || Math.floor(days / 7) % interval !== 0)) return null;
    if (repeat !== 'daily' && repeat !== 'weekly') return null;
  }
  const h = Number(event.time.slice(0, 2));
  const m = Number(event.time.slice(3));
  const rollover = h < GAME_RESET_HOUR ? DAY_MS : 0;
  // Convert a game-date midnight to a Korean-local wall-clock timestamp.
  return candidate - KST_OFFSET_MS + h * 3600000 + m * 60000 + rollover;
}
function dueSchedule(events, minutes, nowMs) {
  if (!validMinutes(minutes) || !Array.isArray(events)) return [];
  const gameDay = kstGameDay(nowMs);
  const result = [];
  for (const event of events.slice(0, 300)) {
    if (typeof event.title !== 'string' || !event.title.trim() || typeof event.id !== 'string') continue;
    for (const offset of [-1, 0, 1]) {
      const at = occurrence(event, addDay(gameDay, offset));
      if (at === null || !dueInWindow(at - minutes * 60000, nowMs)) continue;
      result.push({id: event.id, title: event.title.slice(0, 120), at, minutes});
    }
  }
  return result;
}
function dueShield(endsAt, minutes, nowMs) {
  if (!validMinutes(minutes) || typeof endsAt !== 'string' || !endsAt) return null;
  const end = Date.parse(endsAt);
  if (!Number.isFinite(end)) return null;
  return dueInWindow(end - minutes * 60000, nowMs) ? {at: end, minutes} : null;
}
module.exports = { kstGameDay, occurrence, dueSchedule, dueShield, validMinutes, WINDOW_MS };
